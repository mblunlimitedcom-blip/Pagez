
export enum View {
  BLUEPRINTS = 'BLUEPRINTS',
  STRATEGY = 'STRATEGY',
  VIBE_TIME = 'VIBE_TIME',
  LEGAL = 'LEGAL',
  IP_INTEGRITY = 'IP_INTEGRITY',
  SAMPLE_CLEAR = 'SAMPLE_CLEAR',
  ADMIN = 'ADMIN'
}

export interface Task {
  id: string;
  label: string;
  completed: boolean;
}

export interface Blueprint {
  id: string;
  title: string;
  tasks: Task[];
}

export interface GroundingSource {
  web?: {
    uri: string;
    title: string;
  };
}
