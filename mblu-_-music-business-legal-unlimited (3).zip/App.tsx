import React, { useState, useEffect, useMemo } from 'react';
import { 
  Map as MapIcon, Target, Sparkles, Gavel, Fingerprint, Music,
  Loader2, GraduationCap, Award, LogOut, Copy, Mail,
  Check, Crown, Zap, Palette, Monitor, Smartphone, Laptop, Info, AlertTriangle, ShieldAlert, ShieldCheck, Download, Apple, Smartphone as AndroidIcon, Globe, Terminal, ShieldX, Clock, Database, ExternalLink, Menu, X, Settings2,
  Youtube, PlayCircle, Radio, Disc
} from 'lucide-react';
import { GoogleGenAI } from "@google/genai";
import { View, Blueprint } from './types';
import BlueprintsView from './components/BlueprintsView';
import StrategyLab from './components/StrategyLab';
import FocusZone from './components/FocusZone';
import LegalHub from './components/LegalHub';
import IPIntegrity from './components/IPIntegrity';
import SampleProtocol from './components/SampleProtocol';
import AdminRegistryView from './components/AdminRegistryView';
import { db, doc, getDoc, setDoc } from './firebase';

// ASSET ID MAP
const ASSET_IDS = {
  royal: "1Afdk-q2GICZuCPyTaE0x_ARNo1QZ39LR",
  blue: "1mQXxK-pROzzDpX0fJlZyu0Jgtph6-0yS",
  capture: "1cqXDaDe5-dVahYqvKHQjMUDYSg61mgPS" 
};

const Logo: React.FC<{ className?: string, variant?: 'large' | 'small', isElectric: boolean, theme: 'royal' | 'blue' }> = ({ className, variant = 'large', isElectric, theme }) => {
  const [attempt, setAttempt] = useState(0);
  const [hasError, setHasError] = useState(false);
  const [currentSrc, setCurrentSrc] = useState('');

  useEffect(() => {
    setAttempt(0);
    setHasError(false);
    updateSrc(0);
  }, [theme, variant]);

  const updateSrc = (retryCount: number) => {
    const id = theme === 'blue' ? ASSET_IDS.blue : ASSET_IDS.royal;
    if (retryCount === 0) setCurrentSrc(`https://lh3.googleusercontent.com/d/${id}`);
    else if (retryCount === 1) setCurrentSrc(`https://drive.google.com/uc?export=view&id=${id}`);
    else if (retryCount === 2) setCurrentSrc(`https://drive.google.com/thumbnail?id=${id}&sz=w3840`);
  };

  const handleError = () => {
    if (attempt < 2) {
      const nextAttempt = attempt + 1;
      setAttempt(nextAttempt);
      updateSrc(nextAttempt);
    } else {
      setHasError(true);
    }
  };

  const getImageStyle = () => {
    if (isElectric) {
       return { 
        filter: theme === 'blue' 
          ? 'sepia(1) saturate(6) hue-rotate(170deg) brightness(1.4) contrast(1.2) drop-shadow(0 0 15px rgba(56,189,248,0.6))' 
          : 'sepia(1) saturate(8) hue-rotate(5deg) brightness(1.5) contrast(1.3) drop-shadow(0 0 15px rgba(251,191,36,0.6))', 
        mixBlendMode: 'screen' as const 
      };
    }
    return { 
      filter: theme === 'blue'
        ? 'sepia(1) saturate(4) hue-rotate(180deg) brightness(1.2) contrast(1.1)'
        : 'sepia(1) saturate(5) hue-rotate(10deg) brightness(1.3) contrast(1.2)', 
      mixBlendMode: 'screen' as const 
    };
  };

  if (hasError) {
    return (
      <div className={`flex flex-col items-center ${className}`}>
        <h1 className={`font-varsity tracking-widest text-accent-500 uppercase leading-none ${variant === 'large' ? 'text-6xl md:text-[8rem]' : 'text-xl'} ${isElectric ? 'animate-pulse drop-shadow-[0_0_20px_rgb(var(--accent-400))]' : ''}`}>
          MBLU
        </h1>
        {variant === 'large' && (
           <>
            <div className={`w-16 md:w-24 h-1 rounded-full my-3 md:my-6 shadow-[0_0_20px_rgb(var(--brand-600))] bg-brand-700 ${isElectric ? 'shadow-[0_0_30px_rgb(var(--brand-500))] bg-brand-600' : ''}`}></div>
            <h2 className={`font-varsity text-base md:text-2xl tracking-[0.15em] md:tracking-[0.25em] text-center px-4 leading-tight text-white ${isElectric ? 'text-glow' : ''}`}>
              MUSIC BUSINESS LEGAL UNLIMITED
            </h2>
           </>
        )}
      </div>
    );
  }

  return (
    <img 
      src={currentSrc} 
      alt="MBLU" 
      className={`${
        variant === 'large' 
          ? 'max-w-xs md:max-w-xl mb-4' 
          : 'w-24 md:w-36'
      } h-auto object-contain transition-all duration-700 ${className}`} 
      style={getImageStyle()}
      onError={handleError} 
    />
  );
};

const FloatingNotes: React.FC<{ isElectric: boolean }> = ({ isElectric }) => {
  const notes = useMemo(() => {
    return Array.from({ length: 25 }).map((_, i) => ({
      id: i,
      left: Math.random() * 95,
      animDuration: 10 + Math.random() * 20,
      animDelay: Math.random() * -30,
      size: 15 + Math.random() * 50,
    }));
  }, []);

  return (
    <div className="absolute inset-0 overflow-hidden pointer-events-none z-[1]">
      {notes.map((note) => (
        <div
          key={note.id}
          className={`absolute text-accent-500/20 ${isElectric ? 'drop-shadow(0_0_20px_rgb(var(--accent-400))) animate-pulse' : ''}`}
          style={{
            left: `${note.left}%`,
            bottom: '-100px',
            animation: `float ${isElectric ? note.animDuration * 0.7 : note.animDuration}s linear infinite`,
            animationDelay: `${note.animDelay}s`,
          }}
        >
          <Music size={note.size} strokeWidth={1} />
        </div>
      ))}
    </div>
  );
};

const StoreNode: React.FC<{ icon: React.ReactNode, label: string, url: string, isElectric: boolean }> = ({ icon, label, url, isElectric }) => (
  <a 
    href={url} 
    target="_blank" 
    rel="noreferrer" 
    className="flex flex-col items-center gap-1.5 group transition-all duration-500"
  >
    <div className={`transition-all duration-500 transform group-hover:scale-110 group-hover:-translate-y-1 ${
      isElectric 
        ? 'text-accent-500 group-hover:text-accent-300 drop-shadow-[0_0_15px_rgb(var(--accent-500)/0.4)]' 
        : 'text-white/30 group-hover:text-white'
    }`}>
      {React.cloneElement(icon as React.ReactElement, { size: 28, strokeWidth: 1.5 })}
    </div>
    <span className={`text-[6px] md:text-[8px] font-mono uppercase tracking-[0.4em] font-black transition-all duration-500 ${
      isElectric 
        ? 'text-accent-500 group-hover:text-white' 
        : 'text-white/20 group-hover:text-white/60'
    }`}>
      {label}
    </span>
  </a>
);

const PoweredByFooter: React.FC<{ isElectric: boolean, theme: 'royal' | 'blue' }> = ({ isElectric, theme }) => (
  <div className="mt-12 md:mt-20 mb-8 md:mb-12 flex flex-col items-center gap-4 md:gap-6 relative z-10 animate-in fade-in duration-1000">
    <span className={`font-varsity text-[8px] md:text-sm tracking-[1em] md:tracking-[1.2em] uppercase transition-all duration-700 animate-pulse ${isElectric ? 'text-white drop-shadow-[0_0_35px_rgb(var(--accent-500))]' : 'text-white/40'}`}>
      POWERED BY
    </span>
    
    <div className="flex flex-wrap items-center justify-center gap-6 md:gap-16 px-4 w-full max-w-6xl">
       <StoreNode icon={<Apple />} label="Apple" url="https://music.apple.com/us/artist/y-dresta/265398176" isElectric={isElectric} />
       <StoreNode icon={<PlayCircle />} label="Spotify" url="https://open.spotify.com/episode/7h9Qxtq6cEMhLJ0voELLxc" isElectric={isElectric} />
       <StoreNode icon={<Youtube />} label="Video" url="https://www.youtube.com/watch?v=ZztNwQqgaDw&list=RDZztNwQqgaDw&start_radio=1" isElectric={isElectric} />
       <StoreNode icon={<Radio />} label="Tidal" url="https://tidal.com/artist/4372864" isElectric={isElectric} />
       <StoreNode icon={<Smartphone />} label="Pandora" url="https://www.pandora.com/artist/lil-karma/ARn3rKcm5g79Zqq" isElectric={isElectric} />
    </div>
  </div>
);

const CryptoAddress: React.FC<{ coin: string, address: string, isElectric: boolean }> = ({ coin, address, isElectric }) => {
  const [copied, setCopied] = useState(false);
  const copy = () => {
    navigator.clipboard.writeText(address);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };
  return (
    <div className={`p-2.5 md:p-3.5 rounded-xl md:rounded-2xl border flex items-center justify-between group transition-all cursor-pointer ${isElectric ? 'bg-black/40 border-accent-500/30 hover:shadow-[0_0_15px_rgb(var(--accent-500)/0.3)]' : 'bg-brand-900/10 border-white/30 hover:bg-brand-900/20'}`} onClick={copy}>
      <div className="flex items-center gap-2 md:gap-3 overflow-hidden">
        <div className={`w-7 h-7 md:w-9 md:h-9 rounded-full flex items-center justify-center font-bold text-[9px] md:text-xs shrink-0 ${isElectric ? 'bg-accent-500 text-black shadow-[0_0_10px_rgb(var(--accent-500))]' : 'bg-brand-600 text-white'}`}>
          {coin}
        </div>
        <div className="flex flex-col overflow-hidden">
          <span className="text-[7px] md:text-[9px] font-mono text-white uppercase tracking-widest font-black drop-shadow-sm">Account</span>
          <span className="font-mono text-[8px] md:text-xs text-white truncate w-20 md:w-40 font-black drop-shadow-sm">{address}</span>
        </div>
      </div>
      <div className={`p-1.5 rounded-lg transition-colors ${copied ? 'text-emerald-500 bg-emerald-500/10' : 'text-white/40 group-hover:text-white'}`}>
        {copied ? <Check size={12} /> : <Copy size={12} />}
      </div>
    </div>
  );
};

const NavItem: React.FC<{ icon: React.ReactNode, label: string, active: boolean, onClick: () => void, isSpecial?: boolean, isElectric: boolean }> = ({ icon, label, active, onClick, iSpecial, isElectric }) => (
  <button 
    onClick={onClick}
    className={`w-full flex items-center gap-3 px-6 py-3.5 rounded-xl transition-all duration-300 group relative overflow-hidden ${
      active 
        ? iSpecial 
          ? 'bg-brand-600 text-white shadow-[0_0_20px_rgb(var(--brand-600))]' 
          : isElectric 
            ? 'bg-accent-500 text-black shadow-[0_0_15px_rgb(var(--accent-500))]'
            : 'bg-white text-black shadow-[0_0_20_rgba(255,255,255,0.3)]'
        : 'text-white/70 hover:bg-white/5 hover:text-white'
    }`}
  >
    <div className={`relative z-10 transition-transform duration-300 ${active ? 'scale-110' : 'group-hover:scale-110'}`}>
      {React.cloneElement(icon as React.ReactElement, { 
        size: 18, 
        className: active && isElectric && !iSpecial ? 'text-black' : '' 
      })}
    </div>
    <span className={`font-varsity text-sm md:text-base tracking-widest mt-0.5 relative z-10 font-black ${active ? '' : 'opacity-80'}`}>{label}</span>
  </button>
);

const MobileNavItem: React.FC<{ icon: React.ReactNode, active: boolean, onClick: () => void, isElectric: boolean }> = ({ icon, active, onClick, isElectric }) => (
  <button 
    onClick={onClick}
    className={`p-2 rounded-lg transition-all ${
      active 
        ? isElectric 
          ? 'bg-accent-500 text-black shadow-[0_0_15px_rgb(var(--accent-500))] scale-110' 
          : 'bg-white text-black shadow-[0_0_15px_rgba(255,255,255,0.3)] scale-110'
        : 'text-white/40'
    }`}
  >
    {React.cloneElement(icon as React.ReactElement, { size: 18 })}
  </button>
);

const PlatformIcon: React.FC<{ icon: React.ReactNode, label: string, url?: string, isElectric: boolean }> = ({ icon, label, url, isElectric }) => {
  const content = (
    <div className="flex flex-col items-center gap-2 group cursor-pointer transition-all duration-500">
      <div className={`transition-all duration-500 transform group-hover:-translate-y-2 group-hover:scale-110 text-white ${isElectric ? 'group-hover:text-accent-400 drop-shadow(0 0 25px rgb(var(--accent-500)))' : 'group-hover:text-accent-500'}`}>
        {React.cloneElement(icon as React.ReactElement, { size: 36, md: 48 })}
      </div>
      <span className={`text-[7px] md:text-[10px] font-mono uppercase tracking-[0.4em] font-black transition-all text-white drop-shadow-sm ${isElectric ? 'group-hover:text-accent-400' : 'opacity-40 group-hover:opacity-100'}`}>
        {label}
      </span>
    </div>
  );
  return url ? <a href={url} target="_blank" rel="noreferrer" className="no-underline">{content}</a> : content;
};

const App: React.FC = () => {
  const [isAuthorized, setIsAuthorized] = useState<boolean | null>(null);
  const [activeView, setActiveView] = useState<View>(View.BLUEPRINTS);
  const [leaseRemaining, setLeaseRemaining] = useState<number | null>(null);
  const [verifiedUser, setVerifiedUser] = useState<string>('');
  
  const [loginEmail, setLoginEmail] = useState('');
  const [inputKey, setInputKey] = useState('');
  const [isVerifying, setIsVerifying] = useState(false);
  const [isAdminPortal, setIsAdminPortal] = useState(false); 
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  
  const [themeColor, setThemeColor] = useState<'royal' | 'blue'>('royal');
  const [isElectric, setIsElectric] = useState(false);

  const ADMIN_EMAIL = "mblunlimited.com@gmail.com";

  const PAYMENT_ADDRESSES = {
    BTC: "bc1qukg5l9pqzrtt6fnmukmv28c6whk90jcaq9tgrs",
    DGB: "DQapb3tdS4J1CeSFUVFXYnqzpAco3UUz6s",
    LTC: "LZRmnmaE1fwrufueyUjv5tB6hQMEaJTNVR"
  };

  const [blueprints, setBlueprints] = useState<Blueprint[]>([
    {
      id: 'bp_01',
      title: 'Global Distribution Protocol',
      tasks: [
        { id: 't1', label: 'Step 1: Write/Create', completed: false },
        { id: 't2', label: 'Step 2: Record Mix Master', completed: false },
        { id: 't3', label: 'Step 3: Art Work', completed: false },
        { id: 't4', label: 'Step 4: Distro CD Baby/ Distro Kid', completed: false },
        { id: 't5', label: 'Step 5: Double Check All Work', completed: false },
        { id: 't6', label: 'Step 6: Upload', completed: false },
        { id: 't7', label: 'Step 7: Promote', completed: false }
      ]
    },
    {
      id: 'bp_02',
      title: 'Artist Growth & Promotion',
      tasks: [
        { id: 't8', label: 'TIKTOK TREND PROMOTION', completed: false },
        { id: 't9', label: 'Email List Subscription', completed: false },
        { id: 't10', label: 'Spotify Canvas Sync', completed: true }
      ]
    }
  ]);

  const toggleTask = (bpId: string, taskId: string) => {
    setBlueprints(prev => prev.map(bp => (bp.id === bpId 
      ? { ...bp, tasks: bp.tasks.map(t => t.id === taskId ? { ...t, completed: !t.completed } : t) } 
      : bp)));
  };

  useEffect(() => {
    const savedColor = localStorage.getItem('mblu_theme_color');
    if (savedColor === 'blue') setThemeColor('blue');
    
    const savedElectric = localStorage.getItem('mblu_electric');
    if (savedElectric === 'true') setIsElectric(true);

    const leaseData = localStorage.getItem('mblu_session_lease');
    if (leaseData) {
      try {
        const parsed = JSON.parse(leaseData);
        if (parsed?.status === 'VERIFIED' && Date.now() < parsed.expiryDate) {
          setVerifiedUser(parsed.user);
          setLeaseRemaining(Math.max(0, Math.ceil((parsed.expiryDate - Date.now()) / (24 * 60 * 60 * 1000))));
          if (parsed.isAdmin) setActiveView(View.ADMIN);
          setIsAuthorized(true);
        } else {
          handleReturnToLogin();
        }
      } catch (e) { 
        handleReturnToLogin();
      }
    } else {
      setIsAuthorized(false);
    }
  }, []);

  const handleReturnToLogin = () => {
    localStorage.removeItem('mblu_session_lease');
    setIsAuthorized(false);
    setVerifiedUser('');
    setLeaseRemaining(null);
    setLoginEmail('');
    setInputKey('');
    setActiveView(View.BLUEPRINTS);
  };

  const toggleThemeColor = () => {
    const newColor = themeColor === 'royal' ? 'blue' : 'royal';
    setThemeColor(newColor);
    localStorage.setItem('mblu_theme_color', newColor);
  };

  const toggleElectric = () => {
    const newState = !isElectric;
    setIsElectric(newState);
    localStorage.setItem('mblu_electric', String(newState));
  };

  const attemptLogin = async () => {
    const cleanEmail = loginEmail.trim().toLowerCase();
    const cleanKey = inputKey.trim();
    setIsVerifying(true);

    try {
      if (cleanEmail === ADMIN_EMAIL.toLowerCase() || (cleanEmail === "admin" && cleanKey.toUpperCase() === "ROOT")) {
        const lease = { expiryDate: Date.now() + (365 * 24 * 60 * 60 * 1000), user: ADMIN_EMAIL, status: 'VERIFIED', isAdmin: true };
        localStorage.setItem('mblu_session_lease', JSON.stringify(lease));
        setVerifiedUser(ADMIN_EMAIL);
        setLeaseRemaining(365);
        setActiveView(View.ADMIN);
        setIsAuthorized(true);
        return;
      }

      const userDoc = await getDoc(doc(db, "registry", cleanEmail));
      if (userDoc.exists()) {
        const data = userDoc.data();
        if (data.password === cleanKey) {
          if (Date.now() > data.expiry) {
            alert("MEMBERSHIP EXPIRED: Renewal Required.");
          } else {
            const lease = { expiryDate: data.expiry, user: cleanEmail, status: 'VERIFIED', isAdmin: false };
            localStorage.setItem('mblu_session_lease', JSON.stringify(lease));
            setVerifiedUser(cleanEmail);
            setLeaseRemaining(Math.max(0, Math.ceil((data.expiry - Date.now()) / (24 * 60 * 60 * 1000))));
            setIsAuthorized(true);
          }
        } else { alert("ACCESS DENIED: Please check credentials."); }
      } else { 
        alert(`NO RECORD FOUND: Please complete membership registration.`); 
      }
    } catch (e) {
      alert("CONNECTION ERROR: Please try again.");
    } finally {
      setIsVerifying(false);
    }
  };

  const registerNewLease = async (email: string, pass: string, txid?: string) => {
    try {
      await setDoc(doc(db, "registry", email.trim().toLowerCase()), {
        password: pass.trim(),
        txid: txid || 'OFFICIAL_INVITE',
        expiry: Date.now() + (30 * 24 * 60 * 60 * 1000),
        initializedAt: Date.now() 
      });
      alert(`MEMBER ADDED: Access active for ${email}.`);
    } catch (e) {
      alert("ERROR: Failed to update directory.");
    }
  };

  if (isAuthorized === null) return null;

  return (
    <div className={`dark ${themeColor === 'blue' ? 'theme-blue' : ''} ${isElectric ? 'electric' : ''}`}>
      <div className={`min-h-screen transition-colors duration-1000 font-inter bg-base-bg text-white ${isElectric ? 'selection:bg-accent-500 selection:text-black' : ''}`}>
        {!isAuthorized ? (
          <div className="min-h-screen flex flex-col items-center justify-center p-4 md:p-6 relative overflow-hidden font-inter">
            <div className={`absolute inset-0 blueprint-grid pointer-events-none z-0 ${isElectric ? 'opacity-30 animate-pulse' : 'opacity-20'}`}></div>
            <FloatingNotes isElectric={isElectric} />
            
            {/* Minimalist Vertical Icon Stack Under Trigger */}
            <div className="absolute top-4 right-4 md:top-6 md:right-6 z-[100] flex flex-col items-center">
               <button 
                onClick={() => setIsMenuOpen(!isMenuOpen)}
                className={`w-9 h-9 flex items-center justify-center rounded-full transition-all duration-500 border shadow-xl group ${
                  isMenuOpen 
                    ? 'bg-red-600 border-red-400 text-white scale-90' 
                    : isElectric 
                      ? 'bg-accent-500 border-accent-300 text-black shadow-[0_0_12px_rgb(var(--accent-500)/0.4)]' 
                      : 'bg-white/5 border-white/20 text-white hover:bg-white/10'
                }`}
               >
                 {isMenuOpen ? <X size={16} strokeWidth={3} /> : <Settings2 size={16} strokeWidth={2} />}
               </button>

               <div className={`mt-3 flex flex-col items-center gap-2.5 transition-all duration-500 ${
                 isMenuOpen ? 'opacity-100 translate-y-0' : 'opacity-0 -translate-y-4 pointer-events-none'
               }`}>
                  <button 
                    onClick={toggleThemeColor} 
                    title="SWITCH THEME"
                    className={`w-9 h-9 flex items-center justify-center rounded-full transition-all border shadow-lg ${
                      themeColor === 'blue' 
                        ? 'bg-cyan-500/20 border-cyan-400 text-cyan-400' 
                        : 'bg-amber-500/20 border-amber-400 text-amber-400'
                    }`}
                  >
                    <Palette size={16} />
                  </button>

                  <button 
                    onClick={toggleElectric} 
                    title="ELECTRIC MODE"
                    className={`w-9 h-9 flex items-center justify-center rounded-full transition-all border shadow-lg ${
                      isElectric 
                        ? 'bg-accent-500 text-black border-accent-300 shadow-[0_0_15px_rgb(var(--accent-500)/0.4)]' 
                        : 'bg-white/5 border-white/20 text-white hover:bg-white/10'
                    }`}
                  >
                    {isElectric ? <Zap className="animate-pulse" size={16} fill="currentColor" /> : <Crown size={16} />}
                  </button>

                  <button 
                    onClick={() => { setIsAdminPortal(!isAdminPortal); setIsMenuOpen(false); }}
                    title="ACADEMY CORE"
                    className={`w-9 h-9 flex items-center justify-center rounded-full transition-all border shadow-lg ${
                      isAdminPortal 
                        ? 'bg-brand-600 border-brand-400 text-white shadow-[0_0_15px_rgb(var(--brand-600)/0.4)]' 
                        : 'bg-white/5 border-white/20 text-white hover:bg-white/10'
                    }`}
                  >
                    <GraduationCap size={16} />
                  </button>
               </div>
            </div>

            <div className="w-full max-w-4xl space-y-6 relative z-10 text-center animate-in fade-in zoom-in duration-700">
              <div className="flex flex-col items-center justify-center mb-4">
                <Logo variant="large" className={`drop-shadow-[0_0_35px_rgb(var(--brand-600))] ${isElectric ? 'animate-glow' : ''}`} isElectric={isElectric} theme={themeColor} />
                <p className={`font-mono text-[8px] md:text-xs text-white/60 tracking-[0.4em] uppercase font-black drop-shadow-xl ${isElectric ? 'text-accent-500' : ''}`}>MUSIC INDUSTRY GOLD STANDARD</p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 md:gap-8 items-stretch px-4">
                <div className={`glass rounded-[1.5rem] md:rounded-[2.5rem] p-6 md:p-10 flex flex-col space-y-4 md:space-y-6 border-2 transition-all duration-500 ${isAdminPortal ? 'border-brand-600 shadow-[0_0_40px_rgb(var(--brand-600))]' : 'border-white/10'}`}>
                  <div className="space-y-4">
                    <div className="text-left space-y-1">
                      <label className={`font-varsity text-sm md:text-lg uppercase ml-2 tracking-widest font-black text-accent-500 drop-shadow-md`}>ACCOUNT EMAIL</label>
                      <input value={loginEmail} onChange={(e) => setLoginEmail(e.target.value)} placeholder="EMAIL@MBLU" className={`w-full bg-black/40 border-2 border-white/10 rounded-xl py-3 md:py-4 px-5 text-sm md:text-lg text-white font-mono focus:border-accent-500 outline-none transition-all placeholder:text-white/20 placeholder:font-black`} />
                    </div>
                    <div className="text-left space-y-1">
                      <label className={`font-varsity text-sm md:text-lg uppercase ml-2 tracking-widest font-black text-accent-500 drop-shadow-md`}>PASSWORD</label>
                      <input type="password" value={inputKey} onChange={(e) => setInputKey(e.target.value)} placeholder="••••••••" className={`w-full bg-black/40 border-2 border-white/10 rounded-xl py-3 md:py-4 px-5 text-sm md:text-lg text-white font-mono focus:border-accent-500 outline-none transition-all placeholder:text-white/20 placeholder:font-black`} />
                    </div>
                    <button onClick={attemptLogin} disabled={isVerifying || !loginEmail || !inputKey} className="w-full btn-primary py-4 md:py-5 rounded-xl md:rounded-2xl text-lg md:text-2xl disabled:opacity-20 active:scale-[0.98] shadow-2xl">
                      {isVerifying ? <Loader2 className="animate-spin mx-auto" size={24} /> : 'LOGIN TO HUB'}
                    </button>
                  </div>
                </div>

                <div className="glass rounded-[1.5rem] md:rounded-[2.5rem] p-6 md:p-10 border-white/10 flex flex-col justify-between text-left relative overflow-hidden shadow-2xl">
                  <div className="space-y-4 relative z-10">
                    <div className="flex items-center justify-between">
                      <h3 className={`font-varsity text-lg md:text-2xl text-white tracking-widest uppercase font-black drop-shadow-xl ${isElectric ? 'text-glow' : ''}`}>MEMBERSHIP</h3>
                      <div className={`px-2 py-0.5 rounded-full text-[7px] md:text-[9px] font-mono font-black tracking-widest border-2 bg-brand-900/40 text-accent-500 border-accent-500/40`}>$20.00 / 30D</div>
                    </div>
                    <div className="space-y-2 md:space-y-3.5">
                      <CryptoAddress coin="BTC" address={PAYMENT_ADDRESSES.BTC} isElectric={isElectric} />
                      <CryptoAddress coin="LTC" address={PAYMENT_ADDRESSES.LTC} isElectric={isElectric} />
                      <CryptoAddress coin="DGB" address={PAYMENT_ADDRESSES.DGB} isElectric={isElectric} />
                    </div>
                  </div>

                  <div className={`mt-4 p-3 md:p-5 rounded-xl border bg-brand-900/20 border-white/10 space-y-2 relative z-10`}>
                    <div className="flex items-center gap-2 text-accent-500">
                      <Mail size={12} /><span className="font-varsity text-xs md:text-lg tracking-widest uppercase font-black">Registration Steps</span>
                    </div>
                    <p className="text-[7px] md:text-[9px] font-mono text-white/70 leading-tight uppercase tracking-widest font-black">
                      Email <span className="text-accent-500">{ADMIN_EMAIL}</span> with:
                      <br/>Ref ID, Method, and Account Name.
                    </p>
                  </div>
                </div>
              </div>

              <div className="mt-8 w-full animate-in slide-in-from-bottom-8 duration-1000 delay-300">
                <div className="flex flex-wrap justify-center gap-8 md:gap-32 px-4">
                  <PlatformIcon icon={<AndroidIcon />} label="Android" url="https://play.google.com/store/apps" isElectric={isElectric} />
                  <PlatformIcon icon={<Apple />} label="iOS App" url="https://apps.apple.com/us/app" isElectric={isElectric} />
                  <PlatformIcon icon={<Globe />} label="Web Access" url="https://www.google.com/chrome/" isElectric={isElectric} />
                </div>
              </div>

              <PoweredByFooter isElectric={isElectric} theme={themeColor} />
            </div>
          </div>
        ) : (
          <div className="flex flex-col md:flex-row min-h-screen">
            <nav className="hidden md:flex w-80 glass border-r-2 border-white/10 flex-col fixed inset-y-0 left-0 z-[100] bg-black/70 shadow-2xl">
              <div className="p-8 border-b-2 border-white/10 text-center flex flex-col items-center pb-2">
                 <Logo className={`mx-auto mb-1 drop-shadow-2xl text-accent-500 ${isElectric ? 'animate-glow' : ''}`} variant="small" isElectric={isElectric} theme={themeColor} />
                 
                 {/* Tightened Single-Row Promo Section */}
                 <div className="flex items-center justify-center gap-3 mt-4 whitespace-nowrap px-4 bg-white/5 py-3 rounded-2xl border border-white/10">
                   <a 
                     href="https://worldstar.com/" 
                     target="_blank" 
                     rel="noreferrer" 
                     className={`text-lg font-mono tracking-[0.05em] font-black uppercase text-accent-500 transition-all duration-300 flex items-center gap-2 group making-waves-text leading-none`}
                   >
                     Making Waves <span className="inline-block animate-bounce text-xl">🌊</span>
                   </a>
                   <div className="flex flex-col items-start border-l-2 border-white/20 pl-3 leading-none shrink-0">
                     <span className="text-[10px] font-mono uppercase tracking-[0.1em] font-black text-white/40 mb-0.5">Paid</span>
                     <span className="text-[10px] font-mono uppercase tracking-[0.1em] font-black text-white/40">Promotion</span>
                   </div>
                 </div>
              </div>
              
              <div className="flex-grow py-8 px-6 space-y-2 overflow-y-auto custom-scrollbar">
                <NavItem icon={<MapIcon />} label="ROADMAPS" active={activeView === View.BLUEPRINTS} onClick={() => setActiveView(View.BLUEPRINTS)} isElectric={isElectric} />
                <NavItem icon={<Target />} label="STRATEGY LAB" active={activeView === View.STRATEGY} onClick={() => setActiveView(View.STRATEGY)} isElectric={isElectric} />
                <NavItem icon={<Sparkles />} label="VIBE ZONE" active={activeView === View.VIBE_TIME} onClick={() => setActiveView(View.VIBE_TIME)} isElectric={isElectric} />
                <NavItem icon={<Gavel />} label="LEGAL HUB" active={activeView === View.LEGAL} onClick={() => setActiveView(View.LEGAL)} isElectric={isElectric} />
                <NavItem icon={<Fingerprint />} label="IP SCANNER" active={activeView === View.IP_INTEGRITY} onClick={() => setActiveView(View.IP_INTEGRITY)} isElectric={isElectric} />
                <NavItem icon={<Music />} label="CLEARANCE" active={activeView === View.SAMPLE_CLEAR} onClick={() => setActiveView(View.SAMPLE_CLEAR)} isElectric={isElectric} />
                {isAdminPortal && (
                  <div className="pt-4 mt-4 border-t border-white/10">
                    <NavItem icon={<Award className="text-accent-500" />} label="ADMIN HUB" active={activeView === View.ADMIN} onClick={() => setActiveView(View.ADMIN)} iSpecial isElectric={isElectric} />
                  </div>
                )}
              </div>

              <div className="p-6 border-t-2 border-white/10 space-y-4">
                 <div className="flex items-center justify-between px-2">
                   <div className="flex flex-col">
                     <span className="text-[8px] font-mono text-white/40 uppercase tracking-widest mb-0.5 font-black">Account</span>
                     <span className={`text-[10px] font-mono truncate max-w-[120px] font-black uppercase text-white`}>{verifiedUser}</span>
                   </div>
                   <div className="text-right">
                     <span className="text-[8px] font-mono text-white/40 uppercase tracking-widest mb-0.5 font-black">Expiry</span>
                     <span className={`text-lg font-varsity text-white tracking-widest block leading-none font-black`}>{leaseRemaining}D</span>
                   </div>
                 </div>
                 <div className="flex gap-2">
                    <button onClick={toggleThemeColor} className={`glass w-10 h-10 flex items-center justify-center rounded-xl transition-all border ${isElectric ? 'bg-accent-500 text-black border-accent-400' : 'text-white/40 hover:bg-white/10 border-white/10 shadow-lg'}`} title="Theme"><Palette size={16} /></button>
                    <button onClick={toggleElectric} className={`glass w-10 h-10 flex items-center justify-center rounded-xl transition-all border ${isElectric ? 'bg-accent-500 text-black border-accent-400 shadow-[0_0_10px_rgb(var(--accent-500)/0.5)]' : 'text-white/40 hover:bg-white/10 border-white/10'}`} title="Electric Mode">{isElectric ? <Zap className="animate-pulse" size={16} fill="currentColor" /> : <Crown size={16} />}</button>
                    <button onClick={handleReturnToLogin} className={`flex-1 glass border border-white/10 py-2 rounded-xl text-white font-black hover:bg-brand-600 transition-all text-sm font-varsity tracking-widest shadow-xl`}><LogOut size={16} className="inline mr-1" /> EXIT</button>
                 </div>
              </div>
            </nav>

            <main className="flex-1 md:ml-80 p-4 md:p-10 pb-32 md:pb-12 bg-base-bg relative min-h-screen overflow-x-hidden">
               <FloatingNotes isElectric={isElectric} />
               
               <div className="relative z-10 max-w-5xl mx-auto">
                 {activeView === View.BLUEPRINTS && <BlueprintsView blueprints={blueprints} toggleTask={toggleTask} setView={setActiveView} />}
                 {activeView === View.STRATEGY && <StrategyLab />}
                 {activeView === View.VIBE_TIME && <FocusZone />}
                 {activeView === View.LEGAL && <LegalHub />}
                 {activeView === View.IP_INTEGRITY && <IPIntegrity user={verifiedUser} />}
                 {activeView === View.SAMPLE_CLEAR && <SampleProtocol />}
                 {activeView === View.ADMIN && <AdminRegistryView onRegister={registerNewLease} />}
                 
                 <PoweredByFooter isElectric={isElectric} theme={themeColor} />
               </div>
            </main>

            <nav className={`md:hidden fixed bottom-0 left-0 right-0 z-[200] glass border-t-2 border-white/10 bg-base-bg/95 backdrop-blur-xl px-4 py-3 flex justify-around items-center shadow-[0_-10px_40px_rgba(0,0,0,0.8)]`}>
                <MobileNavItem icon={<MapIcon />} active={activeView === View.BLUEPRINTS} onClick={() => setActiveView(View.BLUEPRINTS)} isElectric={isElectric} />
                <MobileNavItem icon={<Target />} active={activeView === View.STRATEGY} onClick={() => setActiveView(View.STRATEGY)} isElectric={isElectric} />
                <MobileNavItem icon={<Sparkles />} active={activeView === View.VIBE_TIME} onClick={() => setActiveView(View.VIBE_TIME)} isElectric={isElectric} />
                <MobileNavItem icon={<Gavel />} active={activeView === View.LEGAL} onClick={() => setActiveView(View.LEGAL)} isElectric={isElectric} />
                <MobileNavItem icon={<Fingerprint />} active={activeView === View.IP_INTEGRITY} onClick={() => setActiveView(View.IP_INTEGRITY)} isElectric={isElectric} />
                <MobileNavItem icon={<Music />} active={activeView === View.SAMPLE_CLEAR} onClick={() => setActiveView(View.SAMPLE_CLEAR)} isElectric={isElectric} />
                {isAdminPortal && <MobileNavItem icon={<Award />} active={activeView === View.ADMIN} onClick={() => setActiveView(View.ADMIN)} isElectric={isElectric} />}
                <button onClick={handleReturnToLogin} className="p-2 text-brand-500"><LogOut size={20} /></button>
            </nav>
          </div>
        )}
      </div>
    </div>
  );
};

export default App;
