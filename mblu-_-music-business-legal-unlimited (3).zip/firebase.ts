import { initializeApp } from "firebase/app";
import { 
  getFirestore, 
  doc as fsDoc, 
  getDoc as fsGetDoc, 
  setDoc as fsSetDoc, 
  deleteDoc as fsDeleteDoc,
  collection as fsCollection, 
  getDocs as fsGetDocs, 
  onSnapshot as fsOnSnapshot 
} from "firebase/firestore";
import { 
  getStorage, 
  ref as storageRef, 
  uploadBytes, 
  getDownloadURL 
} from "firebase/storage";

/**
 * MBLU Cloud Configuration - VERIFIED UPLINK v6.22
 * Google Cloud Storage & Firestore Integration
 */
const firebaseConfig = {
  apiKey: "AIzaSyDB2ep2TUxUm4Fqv3PUyQxDO1Uxs8eALyw",
  authDomain: "mblu-faf10.firebaseapp.com",
  projectId: "mblu-faf10",
  storageBucket: "mblu-faf10.firebasestorage.app",
  messagingSenderId: "672300887558",
  appId: "1:672300887558:web:df147235bf146c7c77dd87",
  measurementId: "G-YXGDLQR89J"
};

let db: any;
let storage: any;
let isMock = false;
let persistenceStatus: 'PERMANENT' | 'VOLATILE' | 'BLOCKED' = 'PERMANENT';

// Simple Event Emitter for Mock Reactivity
const mockEvents = new EventTarget();
const TRIGGER_UPDATE = 'MBLU_MOCK_UPDATE';

// Test LocalStorage availability and persistence
try {
  const testKey = '__mblu_test__';
  localStorage.setItem(testKey, '1');
  localStorage.removeItem(testKey);
  
  if ('storage' in navigator && 'estimate' in navigator.storage) {
    navigator.storage.estimate().then(est => {
      if (est.quota && est.quota < 120000000) {
        persistenceStatus = 'VOLATILE';
      }
    });
  }
} catch (e) {
  persistenceStatus = 'BLOCKED';
}

try {
  const app = initializeApp(firebaseConfig);
  db = getFirestore(app);
  storage = getStorage(app);
} catch (e: any) {
  isMock = true;
  db = { type: 'mock' };
  storage = { type: 'mock' };
}

const mockCollection = (path: string) => {
  const keys = Object.keys(localStorage).filter(k => k.startsWith(path + '/'));
  return keys.map(k => {
    const data = JSON.parse(localStorage.getItem(k) || '{}');
    return { id: k.split('/').pop(), data: () => data };
  });
};

export const doc = (dbInstance: any, ...paths: string[]) => {
  if (isMock || !dbInstance || dbInstance.type === 'mock') {
    return { _mock: true, type: 'doc', path: paths.join('/') };
  }
  return fsDoc(dbInstance, ...paths);
};

export const collection = (dbInstance: any, ...paths: string[]) => {
  if (isMock || !dbInstance || dbInstance.type === 'mock') {
    return { _mock: true, type: 'collection', path: paths.join('/') };
  }
  return fsCollection(dbInstance, ...paths);
};

export const setDoc = async (ref: any, data: any, options?: { merge: boolean }) => {
  if (ref._mock) {
    const key = ref.path;
    let finalData = data;
    if (options?.merge) {
      const existing = JSON.parse(localStorage.getItem(key) || '{}');
      finalData = { ...existing, ...data };
    }
    localStorage.setItem(key, JSON.stringify(finalData));
    mockEvents.dispatchEvent(new CustomEvent(TRIGGER_UPDATE, { detail: { path: ref.path } }));
    return;
  }
  try {
    await fsSetDoc(ref, data, options);
  } catch (e: any) {
    localStorage.setItem(ref.path, JSON.stringify(data));
    mockEvents.dispatchEvent(new CustomEvent(TRIGGER_UPDATE, { detail: { path: ref.path } }));
  }
};

export const deleteDoc = async (ref: any) => {
  if (ref._mock) {
    localStorage.removeItem(ref.path);
    mockEvents.dispatchEvent(new CustomEvent(TRIGGER_UPDATE, { detail: { path: ref.path } }));
    return;
  }
  try {
    await fsDeleteDoc(ref);
  } catch (e: any) {
    localStorage.removeItem(ref.path);
    mockEvents.dispatchEvent(new CustomEvent(TRIGGER_UPDATE, { detail: { path: ref.path } }));
  }
};

export const getDoc = async (ref: any) => {
  if (ref._mock) {
    const data = localStorage.getItem(ref.path);
    return {
      exists: () => !!data,
      data: () => data ? JSON.parse(data) : undefined,
      id: ref.path.split('/').pop()
    };
  }
  try {
    return await fsGetDoc(ref);
  } catch (e: any) {
    const data = localStorage.getItem(ref.path);
    return {
      exists: () => !!data,
      data: () => data ? JSON.parse(data) : undefined,
      id: ref.path?.split('/').pop() || 'unknown'
    };
  }
};

export const getDocs = async (ref: any) => {
  if (ref._mock) {
    const docs = mockCollection(ref.path);
    return { docs };
  }
  try {
    return await fsGetDocs(ref);
  } catch (e: any) {
    return { docs: mockCollection(ref.path) };
  }
};

export const onSnapshot = (ref: any, onNext: (snap: any) => void, onError?: (err: any) => void) => {
  if (ref._mock) {
    const update = () => {
      if (ref.type === 'collection') {
        const docs = mockCollection(ref.path);
        onNext({ docs });
      } else {
        const data = localStorage.getItem(ref.path);
        onNext({
          exists: () => !!data,
          data: () => data ? JSON.parse(data) : undefined,
          id: ref.path.split('/').pop()
        });
      }
    };
    update();
    const listener = (e: any) => {
      if (ref.type === 'collection' || e.detail.path === ref.path) {
        update();
      }
    };
    mockEvents.addEventListener(TRIGGER_UPDATE, listener);
    return () => mockEvents.removeEventListener(TRIGGER_UPDATE, listener);
  }
  return fsOnSnapshot(ref, onNext, (err) => {
    if (onError) onError(err);
  });
};

export const uploadToCloud = async (path: string, blob: Blob) => {
  if (!storage || storage.type === 'mock') {
    console.warn("Storage in MOCK mode. Mirroring to Local Blob URL only.");
    return URL.createObjectURL(blob);
  }
  const fileRef = storageRef(storage, path);
  await uploadBytes(fileRef, blob);
  return await getDownloadURL(fileRef);
};

export { db, storage, isMock, persistenceStatus };