
import React, { useState, useEffect, useRef } from 'react';
import { GoogleGenAI } from "@google/genai";
import { 
  Search, 
  ShieldAlert, 
  ChevronRight, 
  Activity,
  User,
  Check,
  Server,
  Lock,
  Cpu,
  Scale,
  Fingerprint,
  FileCheck,
  ShieldCheck,
  AlertTriangle,
  Globe,
  History,
  X,
  Timer,
  ExternalLink,
  ScanEye,
  Database
} from 'lucide-react';
import { db, doc, setDoc, collection, onSnapshot, getDoc } from '../firebase';

// --- Services ---

const executeAudit = async (principal: string, comparative?: string): Promise<any> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  const compareContext = comparative 
    ? `COMPARE "${principal}" AGAINST "${comparative}".` 
    : `ANALYZE "${principal}" AND IDENTIFY THE TOP 1 MOST SIMILAR EXISTING ARTIST AS A CONFLICT.`;

  const prompt = `Perform a high-stakes Intellectual Property Scan for Music Artist: "${principal}".
  ${compareContext}
  
  CRITICAL INSTRUCTION: You MUST use Google Search to find REAL WORLD facts about this artist.
  - If the artist exists, you MUST cite their GENRE, a FAMOUS TRACK/ALBUM, and their LOCATION/ORIGIN in the summary.
  - If the artist does NOT exist in search results, explicitly state "No established global footprint found."

  RETURN JSON ONLY.
  Structure:
  {
    "meta": {
      "principalName": "${principal}",
      "comparativeName": "Name of conflict or comparative entity found",
      "auditTimestamp": "${new Date().toISOString()}"
    },
    "metrics": {
      "phoneticResonance": number (0-100),
      "digitalDensity": number (0-100),
      "marketConfusionRisk": "Low" | "Medium" | "High" | "Critical"
    },
    "analysis": {
      "summary": "Specific, fact-based summary.",
      "actionableAdvice": "1 specific recommendation."
    }
  }
  `;

  const response = await ai.models.generateContent({
    model: 'gemini-3-pro-preview',
    contents: prompt,
    config: {
      tools: [{ googleSearch: {} }],
      responseMimeType: "application/json"
    }
  });

  return JSON.parse(response.text || '{}');
};

const generateVisualQuery = async (artistName: string): Promise<string> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: `Generate a Google Image Search query string that would show the most relevant OFFICIAL images for the music artist "${artistName}".`,
  });
  return response.text || `${artistName} official music artist`;
};

const consultAttorney = async (auditSummary: string, history: any[], userMsg: string): Promise<string> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: [
      { role: 'user', parts: [{ text: `You are the MBLU AI Artist Advisor. 
      Context: ${auditSummary}. Inquiry: ${userMsg}` }] }
    ],
  });
  return response.text || "Connection interrupted.";
};

// --- Sub-Components ---

const RadarGauge: React.FC<{ score: number, label: string, inverse?: boolean }> = ({ score, label, inverse }) => {
  const getStrokeColor = (s: number) => {
    if (inverse) {
      if (s < 30) return '#10b981'; // emerald
      if (s < 70) return 'rgb(var(--accent-500))'; 
      return 'rgb(var(--brand-500))';
    }
    if (s > 70) return '#10b981';
    if (s > 30) return 'rgb(var(--accent-500))';
    return 'rgb(var(--brand-500))';
  };

  const colorClass = inverse 
    ? (score < 30 ? 'text-emerald-500' : score < 70 ? 'text-accent-500' : 'text-brand-500')
    : (score > 70 ? 'text-emerald-500' : score > 30 ? 'text-accent-500' : 'text-brand-500');

  return (
    <div className="flex flex-col items-center justify-center relative scale-65 xs:scale-70 md:scale-80">
      <div className="relative w-24 h-24 md:w-32 md:h-32">
        <svg className="w-full h-full transform -rotate-90">
          <circle cx="48" cy="48" r="40" stroke="currentColor" strokeWidth="6" fill="transparent" className="text-white/10" />
          <circle 
            cx="48" cy="48" r="40" 
            stroke={getStrokeColor(score)} strokeWidth="6" fill="transparent" 
            strokeDasharray={251} 
            strokeDashoffset={251 - (251 * score) / 100}
            className="transition-all duration-1000 ease-out"
          />
        </svg>
        <div className="absolute inset-0 flex items-center justify-center flex-col">
          <span className={`text-xl md:text-3xl font-varsity font-black ${colorClass} drop-shadow-lg`}>{score}%</span>
        </div>
      </div>
      <span className="text-[8px] md:text-[10px] font-mono uppercase tracking-[0.2em] text-white mt-2 text-center leading-tight font-black drop-shadow-md">{label}</span>
    </div>
  );
};

const LegalTerminal: React.FC<{ auditData: any; auditId: string; user: string; offlineMode: boolean }> = ({ auditData, auditId, user, offlineMode }) => {
  const [messages, setMessages] = useState<any[]>([]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!user || !auditId || offlineMode) return;
    const loadHistory = async () => {
      try {
        const docRef = doc(db, "users", user, "audits", auditId);
        const docSnap = await getDoc(docRef);
        if (docSnap.exists() && docSnap.data().chatHistory) {
          setMessages(docSnap.data().chatHistory);
        } else {
          setMessages([{ role: 'model', text: `MBLU Advisor Hub Active. Analyzing potential conflict: ${auditData.meta.principalName} vs ${auditData.meta.comparativeName}. Similarity: ${auditData.metrics.phoneticResonance}%. How can I help?`, timestamp: Date.now() }]);
        }
      } catch (e) {
        console.error("Failed to load history", e);
      }
    };
    loadHistory();
  }, [auditId, user, offlineMode]);

  useEffect(() => {
    if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
  }, [messages]);

  const sendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || isTyping) return;
    const userMsg = { role: 'user', text: input, timestamp: Date.now() };
    const updatedMessages = [...messages, userMsg];
    setMessages(updatedMessages);
    setInput('');
    setIsTyping(true);

    if (!offlineMode) {
      await setDoc(doc(db, "users", user, "audits", auditId), { chatHistory: updatedMessages }, { merge: true });
    }

    try {
      const response = await consultAttorney(JSON.stringify(auditData), updatedMessages, userMsg.text);
      const finalMessages = [...updatedMessages, { role: 'model', text: response, timestamp: Date.now() }];
      setMessages(finalMessages);
      if (!offlineMode) {
        await setDoc(doc(db, "users", user, "audits", auditId), { chatHistory: finalMessages }, { merge: true });
      }
    } catch (e) { console.error(e); } finally { setIsTyping(false); }
  };

  return (
    <div className="glass border-white/20 bg-black/80 flex flex-col h-[350px] md:h-[450px] rounded-2xl overflow-hidden shadow-2xl">
      <div className="bg-white/5 p-4 border-b border-white/10 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Scale size={14} className="text-accent-500" />
          <span className="text-[10px] font-black text-white font-mono uppercase tracking-widest drop-shadow-md">ADVISOR_TERMINAL</span>
        </div>
        <div className="w-2 h-2 bg-accent-500 rounded-full animate-pulse"></div>
      </div>
      <div ref={scrollRef} className="flex-1 overflow-y-auto p-4 space-y-4 custom-scrollbar">
        {messages.map((m, i) => (
          <div key={i} className={`flex gap-2.5 ${m.role === 'user' ? 'flex-row-reverse' : ''}`}>
             <div className={`w-7 h-7 rounded-full flex items-center justify-center border shrink-0 ${m.role === 'model' ? 'bg-accent-500/10 border-accent-500/40 text-accent-500' : 'bg-white/10 border-white/30 text-white'}`}>
               {m.role === 'model' ? <Scale size={12} /> : <User size={12} />}
             </div>
             <div className={`p-3 rounded-xl text-[10px] md:text-[11px] font-mono leading-relaxed font-black uppercase tracking-widest drop-shadow-md ${m.role === 'model' ? 'bg-accent-500/10 border border-accent-500/30 text-white max-w-[85%]' : 'bg-white/5 border border-white/20 text-white max-w-[85%]'}`}>
               {m.text}
             </div>
          </div>
        ))}
        {isTyping && <div className="text-[9px] font-mono text-white/50 animate-pulse px-3 uppercase tracking-[0.3em] font-black">ANALYZING...</div>}
      </div>
      <form onSubmit={sendMessage} className="p-3 border-t border-white/10 flex gap-2.5 bg-white/5">
        <input 
          value={input}
          onChange={e => setInput(e.target.value)}
          className="flex-1 bg-black/60 border border-white/20 rounded-lg px-4 py-2.5 text-[11px] text-white font-mono focus:border-accent-500 outline-none transition-all placeholder:text-white/30 uppercase tracking-widest font-black"
          placeholder="QUERY..."
        />
        <button type="submit" disabled={!input || isTyping} className="bg-accent-600 hover:bg-accent-500 text-black px-4 rounded-lg text-[9px] font-black font-varsity tracking-widest transition-all shadow-xl active:scale-95">SEND</button>
      </form>
    </div>
  );
};

// --- Main Component ---

const IPIntegrity: React.FC<{ user: string }> = ({ user }) => {
  const [principal, setPrincipal] = useState('');
  const [comparative, setComparative] = useState('');
  const [loading, setLoading] = useState(false);
  const [data, setData] = useState<any>(null);
  const [auditId, setAuditId] = useState<string | null>(null);
  const [history, setHistory] = useState<any[]>([]);
  const [offlineMode, setOfflineMode] = useState(false);
  const [showMobileHistory, setShowMobileHistory] = useState(false);
  const [scanCooldown, setScanCooldown] = useState(0);

  useEffect(() => {
    let interval: any;
    if (scanCooldown > 0) {
      interval = setInterval(() => setScanCooldown(prev => prev - 1), 1000);
    }
    return () => clearInterval(interval);
  }, [scanCooldown]);

  useEffect(() => {
    if (!user) return;
    try {
      const unsub = onSnapshot(collection(db, "users", user, "audits"), 
        (snap) => {
          const docs = snap.docs.map(doc => ({ id: doc.id, ...doc.data() }));
          setHistory(docs.sort((a: any, b: any) => b.timestamp - a.timestamp));
          setOfflineMode(false);
        },
        () => setOfflineMode(true)
      );
      return () => unsub();
    } catch (e) { setOfflineMode(true); }
  }, [user]);

  const runAudit = async () => {
    if (!principal) return;
    setLoading(true);
    setData(null);
    setAuditId(null);
    
    try {
      const result = await executeAudit(principal, comparative);
      setData(result);
      const newId = Date.now().toString();
      setAuditId(newId);
      setScanCooldown(30);
      
      if (!offlineMode) {
        await setDoc(doc(db, "users", user, "audits", newId), {
          timestamp: Date.now(),
          query: principal,
          comparative: comparative || 'AUTO_DETECT',
          data: result,
          chatHistory: []
        });
      }
    } catch (e) {
      console.error(e);
      alert("System Busy: Scanner error.");
    } finally { setLoading(false); }
  };

  const runVisualScan = async () => {
    if (!principal) return;
    try {
      const query = await generateVisualQuery(principal);
      window.open(`https://www.google.com/search?tbm=isch&q=${encodeURIComponent(query)}`, '_blank');
    } catch (e) { console.error(e); }
  };

  const downloadCert = () => {
    if (!data) return;
    const text = `MBLU IP SCAN REPORT\nID: ${auditId}\nARTIST: ${data.meta.principalName}\nSIMILARITY: ${data.metrics.phoneticResonance}%\n\nFINDINGS: ${data.analysis.summary}`;
    const blob = new Blob([text], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `SCAN_REPORT_${auditId}.txt`;
    link.click();
  };

  return (
    <div className="animate-in fade-in duration-1000 min-h-screen bg-black text-white font-inter pb-24 md:pb-12">
      
      {/* Mobile Ledger Modal */}
      {showMobileHistory && (
        <div className="fixed inset-0 z-[300] bg-black/95 backdrop-blur-2xl p-6 flex flex-col animate-in slide-in-from-bottom-10 duration-500 overflow-hidden">
           <div className="flex items-center justify-between mb-8 pb-4 border-b border-white/10">
              <div className="flex items-center gap-3 text-accent-500">
                 <History size={20} />
                 <span className="text-base font-varsity tracking-[0.2em] uppercase mt-1 font-black drop-shadow-xl">HISTORY</span>
              </div>
              <button onClick={() => setShowMobileHistory(false)} className="p-2.5 bg-white/10 rounded-full text-white active:scale-90 border border-white/20"><X size={20} /></button>
           </div>
           <div className="flex-1 overflow-y-auto space-y-4 px-1 custom-scrollbar">
              {history.length === 0 ? (
                 <div className="flex flex-col items-center justify-center py-24 opacity-20">
                   <Database size={64} className="mb-4" /> 
                   <span className="text-[10px] font-mono font-black uppercase tracking-[0.4em] text-white">NO_RECORDS</span>
                 </div>
              ) : (
                 history.map((h, i) => (
                    <div key={i} onClick={() => { setData(h.data); setAuditId(h.id); setShowMobileHistory(false); }} className="p-5 rounded-xl bg-white/5 border border-white/10 active:bg-white/10 transition-all shadow-xl">
                       <div className="flex justify-between items-start mb-2">
                          <span className="font-black text-white text-base truncate max-w-[70%] uppercase tracking-widest drop-shadow-md">{h.query}</span>
                          <span className="text-[9px] text-white font-mono mt-1 font-black bg-white/10 px-2 py-0.5 rounded-full">{new Date(h.timestamp).toLocaleDateString()}</span>
                       </div>
                       <div className="text-[10px] text-zinc-100 font-mono uppercase truncate font-black tracking-widest opacity-80">PROTOCOL: VS {h.comparative || 'AUTO'}</div>
                    </div>
                 ))
              )}
           </div>
        </div>
      )}

      {/* Header */}
      <div className="border-b border-white/10 bg-black p-6 md:p-8 flex flex-col md:flex-row md:items-end justify-between gap-5">
        <div>
          <div className="flex items-center gap-3 mb-1.5">
            <div className="p-3 bg-accent-500/10 rounded-xl border border-accent-500/40">
               <ShieldCheck className="text-accent-500" size={24} />
            </div>
            <h1 className="text-xl md:text-3xl font-varsity font-black tracking-tighter text-white uppercase italic drop-shadow-2xl">
              IP <span className="text-accent-500">SCANNER</span>
            </h1>
          </div>
          <div className="flex items-center gap-2.5 text-white font-mono text-[9px] md:text-xs tracking-[0.3em] uppercase font-black drop-shadow-xl">
            <Server size={14} className="text-accent-500" /> <span>SECURE_VERIFICATION_v8.0</span>
          </div>
        </div>
        <button 
          onClick={() => setShowMobileHistory(true)}
          className="lg:hidden w-full py-3 bg-white/5 rounded-lg border border-white/20 text-accent-500 font-varsity text-[10px] tracking-[0.3em] font-black flex items-center justify-center gap-2 active:scale-[0.98] shadow-xl"
        >
          <History size={16} /> VIEW_REPORTS
        </button>
      </div>

      <div className="p-5 md:p-8 max-w-6xl mx-auto grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-10">
        
        {/* Left Control Panel */}
        <div className="lg:col-span-5 space-y-6">
          <div className="glass p-6 md:p-8 rounded-[1.5rem] border-white/20 bg-white/5 shadow-2xl">
            <h3 className="text-[10px] font-varsity font-black text-accent-500 uppercase tracking-[0.3em] flex items-center gap-2.5 mb-6 drop-shadow-md">
              <Search size={16} /> SCAN_SETTINGS
            </h3>
            
            <div className="space-y-5">
              <div className="space-y-1.5">
                <label className="text-[9px] text-white uppercase font-black tracking-widest ml-1 drop-shadow-sm">Artist Name</label>
                <input 
                  value={principal}
                  onChange={e => setPrincipal(e.target.value)}
                  placeholder="e.g. DJ Blue"
                  className="w-full bg-black/60 border border-white/20 focus:border-accent-500 rounded-lg p-3.5 text-[11px] text-white font-mono outline-none transition-all placeholder:text-white/20 uppercase tracking-widest font-black"
                />
              </div>
              <div className="space-y-1.5">
                <label className="text-[9px] text-white uppercase font-black tracking-widest ml-1 drop-shadow-sm">Conflict Reference</label>
                <input 
                  value={comparative}
                  onChange={e => setComparative(e.target.value)}
                  placeholder="AUTO_DETECT"
                  className="w-full bg-black/60 border border-white/20 focus:border-accent-500 rounded-lg p-3.5 text-[11px] text-white font-mono outline-none transition-all placeholder:text-white/20 uppercase tracking-widest font-black"
                />
              </div>
              
              <button 
                onClick={runAudit}
                disabled={loading || !principal || scanCooldown > 0}
                className={`w-full py-4 rounded-lg font-varsity text-[11px] md:text-xs tracking-[0.4em] font-black flex items-center justify-center gap-2.5 transition-all shadow-2xl active:scale-95 ${
                  scanCooldown > 0 
                    ? 'bg-white/10 text-white/40 border border-white/10' 
                    : 'bg-accent-600 hover:bg-accent-500 text-black'
                }`}
              >
                {loading ? <Cpu className="animate-spin" size={16} /> : scanCooldown > 0 ? <Timer size={16} /> : <Fingerprint size={16} />}
                {loading ? 'SCANNING...' : scanCooldown > 0 ? `RETRY_${scanCooldown}S` : 'START SCAN'}
              </button>
            </div>
          </div>

          <div className="glass p-6 rounded-[1.5rem] border-brand-500/40 bg-brand-500/10 shadow-2xl">
            <h3 className="text-[10px] font-varsity font-black text-brand-500 uppercase tracking-[0.3em] mb-3 flex items-center gap-2.5 drop-shadow-md">
              <ScanEye size={16} /> VISUAL_SCAN
            </h3>
            <p className="text-[10px] text-white mb-5 font-mono leading-relaxed uppercase font-black tracking-widest drop-shadow-sm">VERIFY ARTISTIC PRESENCE ACROSS DATABASES.</p>
            <button 
              onClick={runVisualScan}
              disabled={!principal}
              className="w-full border border-brand-500/40 hover:bg-brand-500/20 text-brand-500 py-3 rounded-lg font-varsity text-[9px] tracking-[0.4em] font-black flex items-center justify-center gap-2.5 transition-all disabled:opacity-30 shadow-lg"
            >
               <ExternalLink size={14} /> IMAGE SEARCH
            </button>
          </div>

          {/* Desktop History View */}
          <div className="hidden lg:block glass p-6 rounded-[1.5rem] border-white/10 bg-white/5 overflow-hidden shadow-2xl">
            <h3 className="text-[10px] font-varsity font-black text-white uppercase tracking-[0.3em] mb-4 flex items-center gap-2.5 drop-shadow-xl">
              <History size={16} /> REPORT_ARCHIVE
            </h3>
            <div className="space-y-2.5 max-h-[300px] overflow-y-auto custom-scrollbar pr-1.5">
              {history.map((h, i) => (
                <div key={i} onClick={() => { setData(h.data); setAuditId(h.id); }} className="p-4 rounded-lg border border-white/10 bg-black/40 hover:border-accent-500/50 cursor-pointer transition-all group shadow-lg">
                  <div className="flex justify-between items-center mb-1">
                    <span className="font-black text-white text-[11px] truncate max-w-[110px] group-hover:text-accent-500 transition-colors uppercase tracking-[0.1em] drop-shadow-md">{h.query}</span>
                    <span className="text-[8px] text-white/50 font-mono font-black">{new Date(h.timestamp).toLocaleDateString()}</span>
                  </div>
                  <div className="text-[8px] text-zinc-100 font-mono truncate uppercase font-black tracking-widest opacity-60">VS {h.comparative || 'AUTO'}</div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Right Analysis Dashboard */}
        <div className="lg:col-span-7">
          {data ? (
            <div className="space-y-6 md:space-y-8 animate-in slide-in-from-bottom-8 duration-700">
              
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-5 md:gap-6">
                <div className="glass p-5 rounded-[1.5rem] border-white/20 bg-black/40 flex flex-col items-center justify-center shadow-xl">
                  <RadarGauge score={data.metrics.phoneticResonance} label="SIMILARITY" inverse />
                </div>
                <div className="glass p-5 rounded-[1.5rem] border-white/20 bg-black/40 flex flex-col items-center justify-center text-center shadow-xl">
                   <div className="p-3 bg-brand-500/20 rounded-full mb-3 border border-brand-500/40">
                      <Activity size={20} className="text-brand-500" />
                   </div>
                   <div className="text-3xl font-varsity font-black text-white tracking-widest drop-shadow-2xl">{data.metrics.digitalDensity}</div>
                   <div className="text-[9px] font-mono text-white uppercase tracking-[0.3em] mt-2 font-black drop-shadow-md">DENSITY</div>
                </div>
                <div className="glass p-5 rounded-[1.5rem] border-white/20 bg-black/40 flex flex-col items-center justify-center text-center shadow-xl">
                   <div className={`p-3 rounded-full mb-3 border ${data.metrics.marketConfusionRisk === 'Critical' || data.metrics.marketConfusionRisk === 'High' ? 'bg-brand-500/20 border-brand-500/40' : 'bg-accent-500/20 border-accent-500/40'}`}>
                      <AlertTriangle size={20} className={data.metrics.marketConfusionRisk === 'Critical' || data.metrics.marketConfusionRisk === 'High' ? 'text-brand-500' : 'text-accent-500'} />
                   </div>
                   <div className={`text-xl font-varsity font-black uppercase tracking-[0.2em] drop-shadow-2xl ${data.metrics.marketConfusionRisk === 'Critical' || data.metrics.marketConfusionRisk === 'High' ? 'text-brand-500' : 'text-accent-500'}`}>
                     {data.metrics.marketConfusionRisk}
                   </div>
                   <div className="text-[9px] font-mono text-white uppercase tracking-[0.3em] mt-2 font-black drop-shadow-md">CONFUSION</div>
                </div>
              </div>

              <div className="glass p-6 md:p-10 rounded-[2rem] border-white/20 bg-black/60 relative overflow-hidden shadow-2xl">
                 <div className="absolute top-0 left-0 w-2 h-full bg-accent-500/60"></div>
                 <div className="text-[10px] text-white font-black uppercase tracking-[0.5em] mb-6 flex items-center gap-2.5 drop-shadow-xl italic">
                    <Cpu size={16} className="text-accent-500" /> ANALYSIS_CORE
                 </div>
                 <p className="text-[11px] md:text-[13px] text-white leading-loose font-mono first-letter:text-accent-500 first-letter:text-4xl first-letter:font-varsity first-letter:mr-2 first-letter:float-left uppercase font-black tracking-widest drop-shadow-md">
                    {data.analysis.summary}
                 </p>
              </div>

              <div className="grid grid-cols-1 xl:grid-cols-2 gap-6 items-stretch">
                <LegalTerminal auditData={data} auditId={auditId || ''} user={user} offlineMode={offlineMode} />
                
                <div className="flex flex-col gap-6">
                  <div className="glass p-8 rounded-[2rem] border-white/20 bg-black/60 flex-1 flex flex-col shadow-2xl">
                    <h3 className="text-[10px] font-black text-white uppercase tracking-[0.4em] mb-6 flex items-center gap-2.5 font-black drop-shadow-xl italic">
                       <ShieldAlert size={16} className="text-accent-500" /> ADVICE
                    </h3>
                    <div className="flex-1 mb-6">
                       <p className="text-[11px] md:text-xs text-white font-mono leading-relaxed border-l-2 border-accent-500/50 pl-4 italic uppercase font-black tracking-widest drop-shadow-md">
                          {data.analysis.actionableAdvice}
                       </p>
                    </div>
                    <button 
                      onClick={downloadCert}
                      className="w-full bg-white text-black py-4 rounded-xl uppercase tracking-[0.4em] font-varsity text-[11px] md:text-xs font-black flex items-center justify-center gap-2.5 transition-all hover:bg-zinc-200 active:scale-95 shadow-xl"
                    >
                      <FileCheck size={20} /> DOWNLOAD REPORT
                    </button>
                  </div>
                </div>
              </div>

            </div>
          ) : (
            <div className="h-full min-h-[450px] rounded-[2.5rem] flex flex-col items-center justify-center border-4 border-dashed border-white/10 bg-white/5 text-center p-10 shadow-inner">
              <div className="w-20 h-20 bg-black/60 rounded-[2rem] flex items-center justify-center mb-6 border border-white/20 relative group overflow-hidden">
                <div className="absolute inset-0 bg-accent-500/10 rounded-[2rem] animate-ping opacity-20"></div>
                <Search className="text-white/40 group-hover:scale-110 transition-transform duration-500" size={32} />
              </div>
              <h2 className="text-xl md:text-3xl font-varsity font-black text-white uppercase tracking-[0.4em] mb-3 drop-shadow-2xl italic">SCANNER STANDBY</h2>
              <p className="text-white font-mono text-[11px] md:text-xs max-w-sm mx-auto uppercase leading-loose tracking-[0.2em] font-black opacity-90 drop-shadow-lg italic">
                ENTER ARTIST PARAMETERS IN THE CONTROL MODULE TO BEGIN HIGH-STAKES PROPERTY ANALYSIS.
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default IPIntegrity;
