
import React, { useState } from 'react';
import { GoogleGenAI, Type } from "@google/genai";
import { 
  Music, 
  Search, 
  Loader2, 
  FileCheck, 
  ChevronRight, 
  Globe, 
  Mail, 
  Scale, 
  Info,
  ExternalLink,
  Copy,
  CheckCircle2,
  Library,
  Disc,
  PenTool,
  DollarSign,
  FileSignature,
  Stamp,
  Instagram,
  Twitter,
  Smartphone,
  Calculator,
  Sliders
} from 'lucide-react';

interface RightsHolder {
  name: string;
  role: string;
  contact?: string;
  share?: string;
}

interface ClearanceData {
  composition: {
    publishers: RightsHolder[];
    songwriters: RightsHolder[];
    proAffiliations: string[];
  };
  master: {
    label: string;
    contactInfo: string;
    parentCompany?: string;
  };
  threatLevel: 'Low' | 'Medium' | 'High';
}

const STEPS = [
  "Identify Rights Holders",
  "Draft Inquiry Email",
  "Negotiate Master Fees",
  "Define Publishing Splits",
  "Sign Final License",
  "Register New Work",
  "Finalize Distribution",
  "Find Contact Info"
];

const SampleProtocol: React.FC = () => {
  const [loading, setLoading] = useState(false);
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<ClearanceData | null>(null);
  const [sources, setSources] = useState<{title: string, uri: string}[]>([]);
  const [step, setStep] = useState(1);
  
  const [draftLoading, setDraftLoading] = useState(false);
  const [generatedDraft, setGeneratedDraft] = useState('');
  const [emailTone, setEmailTone] = useState<'standard' | 'humble' | 'urgent'>('standard');
  
  const [estimateTier, setEstimateTier] = useState<'major' | 'indie' | 'self'>('major');
  const [estimateType, setEstimateType] = useState<'vocal' | 'loop' | 'drums'>('vocal');
  
  const [contactTarget, setContactTarget] = useState('');
  const [contactResults, setContactResults] = useState<any>(null);
  const [contactLoading, setContactLoading] = useState(false);
  const [contactTimer, setContactTimer] = useState(30);
  
  const [auditTimer, setAuditTimer] = useState(60);

  const performClearanceAudit = async () => {
    setLoading(true);
    setResults(null);
    setSources([]);
    setStep(1); 
    setGeneratedDraft('');
    setContactResults(null);
    setContactTarget('');
    setAuditTimer(60);

    const timerInterval = setInterval(() => {
      setAuditTimer((prev) => (prev > 0 ? prev - 1 : 0));
    }, 1000);
    
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      
      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: `Perform a clearance search for: "${query}". 
        Identify the two pillars of music rights: Composition (Publishers/Songwriters) and Master (Record Label).`,
        config: {
          tools: [{ googleSearch: {} }],
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              composition: {
                type: Type.OBJECT,
                properties: {
                  publishers: {
                    type: Type.ARRAY,
                    items: {
                      type: Type.OBJECT,
                      properties: {
                        name: { type: Type.STRING },
                        role: { type: Type.STRING },
                        share: { type: Type.STRING }
                      }
                    }
                  },
                  songwriters: {
                    type: Type.ARRAY,
                    items: {
                      type: Type.OBJECT,
                      properties: {
                        name: { type: Type.STRING },
                        role: { type: Type.STRING }
                      }
                    }
                  },
                  proAffiliations: { type: Type.ARRAY, items: { type: Type.STRING } }
                }
              },
              master: {
                type: Type.OBJECT,
                properties: {
                  label: { type: Type.STRING },
                  contactInfo: { type: Type.STRING },
                  parentCompany: { type: Type.STRING }
                }
              },
              threatLevel: { type: Type.STRING, description: "Low, Medium, or High based on difficulty" }
            }
          }
        }
      });

      setResults(JSON.parse(response.text || '{}'));
      const chunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks || [];
      setSources(chunks.filter((c: any) => c.web).map((c: any) => ({ title: c.web.title, uri: c.web.uri })));
    } catch (e) {
      alert("Search failed. Please try again.");
    } finally {
      clearInterval(timerInterval);
      setLoading(false);
    }
  };

  const generateEmailDraft = async () => {
    if (!results) return;
    setDraftLoading(true);
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const prompt = `Write a professional music sample clearance inquiry for: "${query}".`;
      const response = await ai.models.generateContent({ model: 'gemini-3-flash-preview', contents: prompt });
      setGeneratedDraft(response.text || "");
    } catch (e) { alert("Draft failed."); } finally { setDraftLoading(false); }
  };

  const getCostSimulation = () => {
    let advance = "$0";
    let royalty = "0%";
    let difficulty = "Low";
    if (estimateTier === 'major') { advance = "$5,000+"; royalty = "50%+"; difficulty = "High"; }
    else if (estimateTier === 'indie') { advance = "$1,500"; royalty = "25%"; difficulty = "Medium"; }
    return { advance, royalty, difficulty };
  };

  const simulation = getCostSimulation();

  return (
    <div className="animate-in fade-in duration-1000">
      <div className="mb-12">
        <div className="flex items-center gap-6 mb-6">
          <div className="bg-brand-600/20 p-5 rounded-[2rem] border-2 border-brand-500/40 shadow-brand-500/20 shadow-xl">
            <Music className="text-brand-500" size={48} />
          </div>
          <h1 className="font-varsity text-4xl md:text-8xl font-black tracking-tighter text-slate-900 dark:text-white uppercase italic drop-shadow-2xl">
            SAMPLE<span className="text-brand-500">CLEARANCE</span>
          </h1>
        </div>
        <p className="text-white dark:text-white font-mono text-sm md:text-lg max-w-2xl uppercase tracking-[0.3em] font-black drop-shadow-xl italic">
          RIGHTS IDENTIFICATION AND CLEARANCE WORKFLOW. LOCATE MASTER AND COMPOSITION OWNERS.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-12">
        <div className="lg:col-span-4 space-y-10">
          <div className="glass p-10 rounded-[2.5rem] border-brand-500/40 bg-brand-500/10 shadow-2xl">
            <h3 className="text-[12px] font-varsity font-black text-brand-500 mb-10 flex items-center gap-4 uppercase tracking-[0.4em] drop-shadow-md">
              <Search size={24} /> CLEARANCE_SEARCH
            </h3>
            <div className="space-y-8">
              <input 
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Song Title or Artist..."
                className="w-full bg-black/60 border-2 border-white/20 rounded-2xl px-6 py-6 text-sm text-white focus:border-brand-500 outline-none font-black uppercase tracking-widest placeholder:text-white/20 shadow-inner"
              />
              <button 
                onClick={performClearanceAudit}
                disabled={loading || !query}
                className="w-full bg-brand-600 hover:bg-brand-500 text-white font-black py-8 rounded-[1.5rem] flex items-center justify-center gap-4 tracking-[0.4em] font-varsity text-sm md:text-lg shadow-[0_0_40px_rgb(var(--brand-600)/0.4)] active:scale-95 transition-all"
              >
                {loading ? 'SEARCHING...' : 'START CLEARANCE SEARCH'}
              </button>
            </div>
          </div>

          <div className="glass p-10 rounded-[2.5rem] border-white/20 bg-white/5 shadow-2xl">
            <h3 className="text-[12px] font-varsity font-black text-accent-500 mb-10 flex items-center gap-4 uppercase tracking-[0.4em] drop-shadow-md">
              <Scale size={24} /> CLEARANCE_WORKFLOW
            </h3>
            <div className="space-y-4">
              {STEPS.map((s, i) => (
                <div key={i} className={`flex items-center gap-6 p-6 rounded-[1.5rem] border-2 transition-all duration-500 ${step === i + 1 ? 'bg-accent-600 text-black border-accent-400 shadow-accent-500/40 shadow-xl' : 'text-white border-white/10 bg-white/5 opacity-40'}`}>
                  <span className="text-xl font-black italic">{i + 1}.</span>
                  <span className="text-[12px] font-black uppercase tracking-widest drop-shadow-md">{s}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="lg:col-span-8">
          {results ? (
            <div className="space-y-10 animate-in slide-in-from-bottom-10 duration-700">
              <div className="glass p-12 rounded-[3rem] border-accent-500/40 flex flex-col md:flex-row items-center justify-between bg-accent-500/10 gap-10 shadow-2xl overflow-hidden relative">
                <div className="absolute top-0 right-0 w-32 h-32 bg-accent-500/5 -mr-16 -mt-16 rounded-full blur-3xl"></div>
                <div>
                  <h2 className="text-4xl md:text-6xl font-varsity font-black text-white uppercase tracking-[0.2em] italic drop-shadow-2xl">{query}</h2>
                  <p className="text-sm text-white font-mono tracking-[0.4em] mt-5 uppercase font-black bg-accent-600/30 px-6 py-2 rounded-full inline-block">CLEARANCE LEVEL: {results.threatLevel}</p>
                </div>
                <button onClick={() => setStep(step + 1)} className="w-full md:w-auto px-16 py-8 bg-accent-600 text-black rounded-[2rem] text-xl font-varsity font-black tracking-[0.4em] shadow-[0_20px_40px_rgba(0,0,0,0.4)] active:scale-95 transition-all shadow-accent-500/30">NEXT_STEP</button>
              </div>
            </div>
          ) : (
            <div className="h-full min-h-[700px] rounded-[4rem] flex flex-col items-center justify-center border-4 border-dashed border-white/10 bg-white/5 p-20 text-center shadow-inner">
              <Music size={120} className="text-white/10 mb-10 animate-pulse" />
              <h2 className="text-3xl md:text-5xl font-varsity font-black text-white uppercase tracking-[0.4em] mb-6 drop-shadow-2xl italic">SCANNER READY</h2>
              <p className="text-white font-mono text-base md:text-lg max-w-lg mx-auto uppercase leading-loose tracking-[0.2em] font-black opacity-90 drop-shadow-lg italic">
                START A HIGH-STAKES SEARCH TO IDENTIFY ALL RIGHTS HOLDERS FOR YOUR MASTER SAMPLE.
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default SampleProtocol;
