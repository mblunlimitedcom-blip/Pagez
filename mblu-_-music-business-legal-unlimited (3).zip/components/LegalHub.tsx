
import React, { useState, useEffect } from 'react';
import { GoogleGenAI } from "@google/genai";
import { 
  Search, 
  FileText, 
  BookOpen, 
  Loader2, 
  Copy, 
  Download, 
  ExternalLink,
  Gavel,
  Shield,
  PenTool
} from 'lucide-react';
import { GroundingSource } from '../types';

// Specialized loading overlay for Legal Synthesis
const LegalSynthesisOverlay: React.FC<{ active: boolean }> = ({ active }) => {
  const [step, setStep] = useState(0);
  const steps = [
    "Analyzing Contract Requirements...",
    "Reviewing Industry Templates...",
    "Drafting Protection Clauses...",
    "Calculating Share Allocations...",
    "Finalizing Professional Document..."
  ];

  useEffect(() => {
    if (!active) {
      setStep(0);
      return;
    }
    const interval = setInterval(() => {
      setStep(prev => (prev + 1) % steps.length);
    }, 3000);
    return () => clearInterval(interval);
  }, [active]);

  if (!active) return null;

  return (
    <div className="fixed inset-0 z-[100] bg-slate-950/95 backdrop-blur-2xl flex flex-col items-center justify-center p-8 transition-colors duration-500">
      <div className="w-full max-w-lg text-center space-y-8">
        <div className="w-32 h-32 mx-auto relative">
          <div className="absolute inset-0 bg-brand-500/20 rounded-full animate-ping"></div>
          <div className="relative z-10 bg-brand-500/20 p-8 rounded-full border-2 border-brand-500/40 shadow-[0_0_30px_rgb(var(--brand-500)/0.3)]">
            <PenTool className="text-brand-500 w-full h-full animate-pulse" />
          </div>
        </div>
        <div>
          <h2 className="font-varsity text-3xl text-white tracking-[0.3em] uppercase mb-3 font-black drop-shadow-xl">Legal Hub Active</h2>
          <p className="font-mono text-lg text-brand-400 min-h-[1.5em] transition-all duration-500 uppercase tracking-widest font-black drop-shadow-md">
            {steps[step]}
          </p>
        </div>
        <div className="w-full h-2 bg-white/10 rounded-full overflow-hidden shadow-inner">
          <div className="h-full bg-brand-500 w-1/3 animate-[translateX_3s_ease-in-out_infinite] shadow-[0_0_15px_rgb(var(--brand-500))]"></div>
        </div>
        <p className="text-[12px] text-white font-mono uppercase tracking-[0.4em] font-black drop-shadow-lg">SYNTHESIZING GOLD STANDARD DRAFT.</p>
      </div>
    </div>
  );
};

const LegalHub: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'radar' | 'lab' | 'theory'>('radar');
  const [loading, setLoading] = useState(false);
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<string | null>(null);
  const [sources, setSources] = useState<GroundingSource[]>([]);

  const runRightsRadar = async () => {
    setLoading(true);
    setResults(null);
    setSources([]);
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: `Research the current master and publishing rights ownership for: ${query}. Provide a concise breakdown of who likely owns what based on public records.`,
        config: {
          tools: [{ googleSearch: {} }],
        },
      });

      setResults(response.text || "No search results found.");
      const chunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks || [];
      setSources(chunks as GroundingSource[]);
    } catch (e) {
      console.error(e);
      alert("Search failed. Please try a different query.");
    } finally {
      setLoading(false);
    }
  };

  const synthesizeContract = async () => {
    setLoading(true);
    setResults(null);
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const response = await ai.models.generateContent({
        model: "gemini-3-pro-preview",
        contents: `Create a professional draft for a music industry agreement based on these parameters: ${query}. 
        Format clearly with sections. Include standard clauses for independent artists.`,
        config: {
          thinkingConfig: { thinkingBudget: 10000 }
        }
      });
      setResults(response.text || "Failed to generate document.");
    } catch (e) {
      console.error(e);
      alert("Document hub error.");
    } finally {
      setLoading(false);
    }
  };

  const copyToClipboard = () => {
    if (results) {
      navigator.clipboard.writeText(results);
      alert("COPIED TO HUB CLIPBOARD");
    }
  };

  const downloadText = () => {
    if (results) {
      const element = document.createElement("a");
      const file = new Blob([results], {type: 'text/plain'});
      element.href = URL.createObjectURL(file);
      element.download = "mblu_contract_draft.txt";
      document.body.appendChild(element);
      element.click();
    }
  };

  return (
    <div className="animate-in fade-in slide-in-from-bottom-4 duration-700">
      <LegalSynthesisOverlay active={loading && activeTab === 'lab'} />

      <div className="mb-10">
        <h1 className="font-varsity text-4xl md:text-7xl font-black text-slate-900 dark:text-white mb-2 tracking-tight uppercase">LEGAL HUB</h1>
        <p className="text-white dark:text-white font-mono text-sm md:text-base uppercase tracking-widest font-black drop-shadow-xl">SEARCH RIGHTS, DRAFT CONTRACTS, AND ACCESS GOLD STANDARD KNOWLEDGE.</p>
      </div>

      <div className="flex gap-4 mb-10 border-b-2 border-white/10 overflow-x-auto pb-1">
        <button 
          onClick={() => { setActiveTab('radar'); setResults(null); }}
          className={`px-10 py-5 text-sm font-varsity tracking-[0.2em] transition-all whitespace-nowrap uppercase font-black border-b-4 ${activeTab === 'radar' ? 'text-accent-500 border-accent-500 bg-white/5' : 'text-white/60 hover:text-white hover:bg-white/5 border-transparent'}`}
        >
          RIGHTS SEARCH
        </button>
        <button 
          onClick={() => { setActiveTab('lab'); setResults(null); }}
          className={`px-10 py-5 text-sm font-varsity tracking-[0.2em] transition-all whitespace-nowrap uppercase font-black border-b-4 ${activeTab === 'lab' ? 'text-brand-500 border-brand-500 bg-white/5' : 'text-white/60 hover:text-white hover:bg-white/5 border-transparent'}`}
        >
          DRAFTING LAB
        </button>
        <button 
          onClick={() => { setActiveTab('theory'); setResults(null); }}
          className={`px-10 py-5 text-sm font-varsity tracking-[0.2em] transition-all whitespace-nowrap uppercase font-black border-b-4 ${activeTab === 'theory' ? 'text-accent-500 border-accent-500 bg-white/5' : 'text-white/60 hover:text-white hover:bg-white/5 border-transparent'}`}
        >
          GOLD GLOSSARY
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-10">
        <div className="lg:col-span-4 space-y-8">
          {activeTab === 'radar' && (
            <div className="glass p-10 rounded-[2rem] space-y-8 border-white/20 bg-white/5 shadow-2xl">
              <h3 className="text-sm font-black text-accent-500 uppercase flex items-center gap-3 tracking-[0.3em] drop-shadow-md"><Search size={20}/> SEARCH_INPUT</h3>
              <div className="space-y-3">
                <label className="text-[11px] md:text-sm text-white uppercase font-black tracking-widest ml-1 drop-shadow-sm">Artist or Song Name</label>
                <input 
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                  placeholder="e.g. Michael Jackson or Thriller..."
                  className="w-full bg-black/60 border-2 border-white/30 rounded-2xl p-6 text-sm text-white focus:outline-none focus:border-accent-500 transition-all font-black uppercase tracking-widest placeholder:text-white/30 shadow-inner"
                />
              </div>
              <button 
                onClick={runRightsRadar}
                disabled={loading || !query}
                className="w-full bg-accent-600 hover:bg-accent-500 text-black font-black py-6 rounded-2xl text-lg tracking-[0.2em] font-varsity flex items-center justify-center gap-3 shadow-xl shadow-accent-500/30 active:scale-95 transition-all"
              >
                {loading ? <Loader2 className="animate-spin" size={20} /> : 'SEARCH RECORDS'}
              </button>
            </div>
          )}

          {activeTab === 'lab' && (
            <div className="glass p-10 rounded-[2rem] space-y-8 border-brand-500/40 bg-brand-500/10 shadow-2xl">
              <h3 className="text-sm font-black text-brand-500 uppercase flex items-center gap-3 tracking-[0.3em] drop-shadow-md"><FileText size={20}/> CONTRACT_DETAILS</h3>
              <div className="space-y-3">
                <label className="text-[11px] md:text-sm text-white uppercase font-black tracking-widest ml-1 drop-shadow-sm">Requirement Protocol</label>
                <textarea 
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                  placeholder="e.g. Simple split sheet for a collab..."
                  className="w-full h-56 bg-black/60 border-2 border-white/30 rounded-2xl p-6 text-sm text-white focus:outline-none focus:border-brand-500 transition-all resize-none font-mono font-black uppercase tracking-widest placeholder:text-white/30 shadow-inner"
                />
              </div>
              <button 
                onClick={synthesizeContract}
                disabled={loading || !query}
                className="w-full bg-brand-600 hover:bg-brand-500 text-white font-black py-6 rounded-2xl text-lg tracking-[0.2em] font-varsity flex items-center justify-center gap-3 shadow-xl shadow-brand-500/40 active:scale-95 transition-all"
              >
                {loading ? 'SYNTHESIZING...' : 'GENERATE DRAFT'}
              </button>
            </div>
          )}

          {activeTab === 'theory' && (
            <div className="glass p-10 rounded-[2rem] space-y-10 border-white/20 shadow-2xl bg-white/5">
              <h3 className="text-sm font-black text-accent-500 uppercase flex items-center gap-3 tracking-[0.3em] drop-shadow-md"><BookOpen size={20}/> KEY TERMS</h3>
              <div className="space-y-8">
                <TheoryItem title="Master vs. Composition" content="Master rights belong to the sound recording (.wav). Composition rights belong to the song itself (notes/lyrics)." />
                <TheoryItem title="Interpolation" content="Re-creating a melody or lyric from another song. Requires composition permission but not master permission." />
                <TheoryItem title="Split Sheets" content="The fundamental industry document that defines ownership between multiple creators." />
              </div>
            </div>
          )}
        </div>

        <div className="lg:col-span-8">
          {results ? (
            <div className="glass p-10 md:p-16 rounded-[3rem] min-h-[700px] flex flex-col border-white/20 shadow-[0_0_60px_rgba(0,0,0,0.6)]">
              <div className="flex justify-between items-center mb-10 pb-8 border-b-2 border-white/10">
                <span className="text-xs font-mono text-accent-500 uppercase tracking-[0.3em] font-black drop-shadow-md">SYNTHESIS_OUTPUT</span>
                <div className="flex gap-4">
                  <button onClick={copyToClipboard} className="p-4 bg-white/10 text-white hover:bg-accent-500 hover:text-black rounded-2xl transition-all border border-white/20 shadow-lg"><Copy size={24}/></button>
                  <button onClick={downloadText} className="p-4 bg-white/10 text-white hover:bg-accent-500 hover:text-black rounded-2xl transition-all border border-white/20 shadow-lg"><Download size={24}/></button>
                </div>
              </div>
              
              <div className="flex-1 whitespace-pre-wrap text-sm md:text-base leading-relaxed text-white font-mono overflow-y-auto max-h-[600px] custom-scrollbar font-black uppercase tracking-widest drop-shadow-md">
                {results}
              </div>

              {sources.length > 0 && (
                <div className="mt-12 pt-10 border-t-2 border-white/10">
                  <h4 className="text-[12px] text-accent-500 font-black uppercase mb-6 tracking-[0.4em] drop-shadow-md">VERIFIED SOURCES</h4>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {sources.map((s, idx) => s.web && (
                      <a 
                        key={idx} 
                        href={s.web.uri} 
                        target="_blank" 
                        rel="noreferrer"
                        className="glass px-6 py-5 rounded-2xl text-[12px] text-white hover:text-accent-500 flex items-center justify-between hover:bg-white/10 transition-all border-white/20 uppercase tracking-widest font-black drop-shadow-sm"
                      >
                        <span className="truncate mr-4">{s.web.title}</span>
                        <ExternalLink size={16} />
                      </a>
                    ))}
                  </div>
                </div>
              )}
            </div>
          ) : (
            <div className="glass h-full rounded-[3rem] flex flex-col items-center justify-center text-white/10 p-16 border-dashed border-4 border-white/5 shadow-inner">
              <Gavel size={100} className="mb-8 opacity-10" />
              <p className="font-varsity text-center tracking-[0.4em] text-lg text-white/30 uppercase font-black">SYSTEM READY: WAITING FOR INPUT</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

const TheoryItem: React.FC<{ title: string, content: string }> = ({ title, content }) => (
  <div className="border-l-4 border-accent-500/40 pl-6 group">
    <div className="text-sm font-black text-accent-500 uppercase tracking-widest mb-3 font-varsity group-hover:text-white transition-colors drop-shadow-md">{title}</div>
    <div className="text-[13px] text-white leading-relaxed font-mono uppercase font-black tracking-tight drop-shadow-sm">{content}</div>
  </div>
);

export default LegalHub;
