
import React from 'react';
import { View, Blueprint } from '../types';
import { CheckSquare, Square, ExternalLink, Sparkles, Target } from 'lucide-react';

interface Props {
  blueprints: Blueprint[];
  toggleTask: (bpId: string, taskId: string) => void;
  setView: (v: View) => void;
}

const BlueprintsView: React.FC<Props> = ({ blueprints, toggleTask, setView }) => {
  return (
    <div className="animate-in fade-in slide-in-from-bottom-4 duration-700">
      <div className="mb-6 md:mb-8">
        <h1 className="font-varsity text-2xl md:text-4xl text-slate-900 dark:text-white mb-1 md:mb-1.5 tracking-wide uppercase font-black">RELEASE ROADMAPS</h1>
        <p className="text-white dark:text-white font-mono text-[9px] md:text-xs tracking-tight uppercase font-black drop-shadow-lg">PROFESSIONAL RELEASE WORKFLOWS AND DISTRIBUTION CHECKLISTS.</p>
      </div>

      <div className="space-y-5 md:space-y-6">
        {blueprints.map(bp => (
          <div key={bp.id} className="glass rounded-[1.25rem] md:rounded-[1.5rem] overflow-hidden border border-white/20 group hover:border-white/40 transition-all">
            <div className="bg-brand-500/10 p-3.5 md:p-4.5 border-b border-white/10 flex items-center justify-between">
              <h3 className="font-varsity text-lg md:text-xl text-brand-600 dark:text-brand-400 uppercase tracking-widest font-black">{bp.title}</h3>
              <div className="text-[8px] md:text-[10px] text-white font-mono font-black uppercase tracking-widest drop-shadow-md">
                REF_ID: {bp.id.toUpperCase()}
              </div>
            </div>
            <div className="p-3.5 md:p-6 space-y-2 md:space-y-3">
              {bp.tasks.map(task => (
                <div 
                  key={task.id}
                  onClick={() => toggleTask(bp.id, task.id)}
                  className={`flex items-center gap-2.5 md:gap-3.5 p-3 md:p-4 rounded-xl cursor-pointer transition-all border shadow-lg ${
                    task.completed 
                      ? 'bg-brand-500/20 border-brand-500/40 text-brand-700 dark:text-brand-100' 
                      : 'bg-white/5 border-white/20 hover:border-brand-500/50 text-white'
                  }`}
                >
                  <div className={`transition-transform duration-300 ${task.completed ? 'scale-110' : 'scale-100'}`}>
                    {task.completed ? (
                      <CheckSquare size={18} className="text-brand-500 dark:text-brand-400 drop-shadow-[0_0_10px_rgba(239,68,68,0.6)]" />
                    ) : (
                      <Square size={18} className="text-white drop-shadow-md" />
                    )}
                  </div>
                  <div className="flex-1 flex items-center justify-between overflow-hidden">
                    <span className={`text-[11px] md:text-base font-inter font-black tracking-tight truncate pr-2 transition-all drop-shadow-md ${task.completed ? 'line-through opacity-40 italic' : ''}`}>
                      {task.label}
                    </span>
                    {task.label.includes('PROMOTION') && (
                      <button 
                        onClick={(e) => {
                          e.stopPropagation();
                          setView(View.STRATEGY);
                        }}
                        className="flex items-center gap-1 text-[9px] md:text-[10px] font-varsity font-black text-pink-500 hover:text-pink-400 border border-pink-500/40 px-2 py-1 rounded-lg bg-pink-500/10 transition-all whitespace-nowrap shadow-lg"
                      >
                        <Sparkles size={10} /> <span className="hidden sm:inline">GROWTH LAB</span>
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>
            <div className="bg-black/40 p-3.5 md:p-5 flex items-center gap-3 md:gap-4 border-t border-white/10">
              <div className="flex-1 h-1.5 md:h-2 bg-white/10 rounded-full overflow-hidden">
                <div 
                  className="h-full bg-brand-500 transition-all duration-1000 shadow-[0_0_20px_rgb(var(--brand-500)/0.8)]"
                  style={{ width: `${(bp.tasks.filter(t => t.completed).length / bp.tasks.length) * 100}%` }}
                ></div>
              </div>
              <span className="text-[9px] md:text-[12px] font-varsity font-black text-white uppercase tracking-widest whitespace-nowrap drop-shadow-lg">
                {Math.round((bp.tasks.filter(t => t.completed).length / bp.tasks.length) * 100)}% <span className="hidden sm:inline">COMPLETE</span>
              </span>
            </div>
          </div>
        ))}
      </div>

      <div className="mt-8 md:mt-10 glass p-6 md:p-8 border-accent-500/40 bg-accent-500/10 rounded-[1.5rem] md:rounded-[2rem] flex flex-col md:flex-row items-center justify-between gap-5 md:gap-6 shadow-2xl">
        <div className="flex items-center gap-4 md:gap-6 text-center md:text-left flex-col md:flex-row">
          <div className="bg-accent-500/30 p-4 rounded-xl md:rounded-2xl border-2 border-accent-500/50 shadow-accent-500/20 shadow-xl">
            <Target className="text-accent-500" size={24} />
          </div>
          <div>
            <h4 className="font-varsity text-xl md:text-3xl text-slate-900 dark:text-white uppercase tracking-widest leading-none font-black drop-shadow-xl">NEED A GROWTH PLAN?</h4>
            <p className="text-[10px] md:text-xs text-white font-mono mt-2 uppercase font-black tracking-widest drop-shadow-lg max-w-lg">GENERATE YOUR 4-WEEK MARKETING ROADMAP VIA AI POWERED SYNTHESIS.</p>
          </div>
        </div>
        <button 
          onClick={() => setView(View.STRATEGY)}
          className="w-full md:w-auto bg-accent-600 hover:bg-accent-500 text-white font-black py-4 md:py-5 px-8 md:px-12 rounded-xl md:rounded-2xl font-varsity text-xl md:text-2xl tracking-widest transition-all shadow-2xl shadow-accent-500/40 active:scale-95"
        >
          ENTER LAB <ExternalLink size={18} className="inline ml-2 mb-1" />
        </button>
      </div>
    </div>
  );
};

export default BlueprintsView;
