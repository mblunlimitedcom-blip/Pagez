
import React from 'react';
import { View, Blueprint } from '../types';
import { Activity, Gavel, ArrowUpRight, Target } from 'lucide-react';

interface Props {
  blueprints: Blueprint[];
  setView: (v: View) => void;
}

const DashboardView: React.FC<Props> = ({ blueprints, setView }) => {
  const calculateProgress = (bp: Blueprint) => {
    if (bp.tasks.length === 0) return 0;
    const completed = bp.tasks.filter(t => t.completed).length;
    return Math.round((completed / bp.tasks.length) * 100);
  };

  return (
    <div className="animate-in fade-in slide-in-from-bottom-4 duration-700">
      <div className="mb-8">
        <h1 className="font-orbitron text-4xl font-bold text-white mb-2 tracking-tight">COMMAND CENTER</h1>
        <p className="text-cyan-500/60 max-w-xl">Centralized telemetry for Music Business Legal Unlimited. Execute operational engines, synthesize strategy, and protect your artistic focus.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <div className="glass p-6 rounded-lg relative overflow-hidden group">
          <div className="absolute top-0 right-0 p-2 opacity-20 group-hover:opacity-100 transition-opacity">
            <Activity className="text-cyan-400" />
          </div>
          <div className="text-xs text-cyan-500/60 mb-1 uppercase tracking-widest font-bold">Active Engines</div>
          <div className="text-4xl font-orbitron text-white">{blueprints.length}</div>
          <div className="mt-4 text-[10px] text-emerald-400 flex items-center gap-1">
            <ArrowUpRight size={10} /> +12% Efficiency vs Prev Phase
          </div>
        </div>

        <div className="glass p-6 rounded-lg relative overflow-hidden group">
          <div className="absolute top-0 right-0 p-2 opacity-20 group-hover:opacity-100 transition-opacity">
            <Target className="text-pink-400" />
          </div>
          <div className="text-xs text-pink-500/60 mb-1 uppercase tracking-widest font-bold">Strategy Status</div>
          <div className="text-4xl font-orbitron text-white">READY</div>
          <div className="mt-4 text-[10px] text-pink-500 flex items-center gap-1">
            Gemini-3-Flash Connected
          </div>
        </div>

        <div 
          onClick={() => setView(View.LEGAL)}
          className="glass p-6 rounded-lg bg-pink-500/5 border-pink-500/20 cursor-pointer hover:bg-pink-500/10 transition-colors group relative"
        >
          <div className="absolute top-0 right-0 p-2 text-pink-500">
            <Gavel size={20} />
          </div>
          <div className="text-xs text-pink-500 mb-1 uppercase tracking-widest font-bold">Urgent Action</div>
          <div className="text-lg font-orbitron text-white leading-tight mt-2">Legal Lab synthesis required for master rights.</div>
          <button className="mt-4 text-xs font-bold text-pink-400 border border-pink-500/30 px-3 py-1 rounded group-hover:bg-pink-500 group-hover:text-white transition-all">
            LAUNCH RADAR
          </button>
        </div>
      </div>

      <h2 className="font-orbitron text-xl text-cyan-400 mb-6 flex items-center gap-2">
        <span className="w-2 h-2 bg-cyan-400 inline-block animate-pulse"></span>
        OPERATIONAL ENGINES
      </h2>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {blueprints.map(bp => (
          <div key={bp.id} className="glass p-4 rounded border-l-4 border-cyan-500">
            <div className="flex justify-between items-start mb-4">
              <span className="font-orbitron text-sm font-bold truncate max-w-[200px] uppercase tracking-tighter">{bp.title}</span>
              <span className="text-xs font-mono text-cyan-400">{calculateProgress(bp)}%</span>
            </div>
            <div className="h-1.5 w-full bg-slate-800 rounded-full overflow-hidden">
              <div 
                className="h-full bg-cyan-500 shadow-[0_0_10px_rgba(6,182,212,0.8)] transition-all duration-1000" 
                style={{ width: `${calculateProgress(bp)}%` }}
              ></div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default DashboardView;
