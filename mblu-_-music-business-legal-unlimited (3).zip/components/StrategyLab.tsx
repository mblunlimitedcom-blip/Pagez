
import React, { useState } from 'react';
import { GoogleGenAI } from "@google/genai";
import { Sparkles, Loader2, Target, EyeOff } from 'lucide-react';

const StrategyLab: React.FC = () => {
  const [loading, setLoading] = useState(false);
  const [artistData, setArtistData] = useState({ genre: '', goals: '', releaseType: 'Single' });
  const [roadmap, setRoadmap] = useState<string | null>(null);

  const generateStrategy = async () => {
    setLoading(true);
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const prompt = `Act as a world-class music industry strategist. Create a 4-week marketing roadmap for a ${artistData.genre} artist focused on ${artistData.goals} for a ${artistData.releaseType} release. 
      Include a specific "Noise Blockers" section to help the artist avoid vanity metrics (likes, play counts) and focus on real community/legal ownership. Format as Markdown.`;
      
      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: prompt,
      });
      
      setRoadmap(response.text || "Strategy generation complete.");
    } catch (error) {
      console.error(error);
      alert("Failed to generate strategy. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="animate-in fade-in slide-in-from-bottom-4 duration-700">
      <div className="mb-6 md:mb-8">
        <h1 className="font-varsity text-2xl md:text-4xl font-black text-slate-900 dark:text-white mb-1.5 tracking-tight uppercase">STRATEGY LAB</h1>
        <p className="text-white dark:text-white font-mono text-[11px] md:text-xs uppercase tracking-widest font-black drop-shadow-lg">GENERATE HIGH-CONVERSION RELEASE PLANS VIA AI-DRIVEN STRATEGIC ANALYSIS.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 md:gap-10">
        <div className="lg:col-span-1 space-y-6 md:space-y-8">
          <div className="glass p-6 md:p-8 rounded-[1.5rem] md:rounded-[2rem] space-y-6 md:space-y-8 border-white/20 shadow-2xl bg-white/5">
            <h3 className="text-[10px] font-black text-accent-500 uppercase tracking-[0.3em] flex items-center gap-2.5 drop-shadow-md">
              <Target size={16} /> CAMPAIGN DETAILS
            </h3>
            
            <div className="space-y-2">
              <label className="text-[9px] md:text-[10px] text-white uppercase font-black tracking-widest ml-1 drop-shadow-sm">Genre / Style</label>
              <input 
                value={artistData.genre}
                onChange={(e) => setArtistData({ ...artistData, genre: e.target.value })}
                className="w-full bg-black/60 border-2 border-white/20 rounded-xl py-3.5 px-5 text-sm text-white focus:outline-none focus:border-accent-500 transition-all font-black uppercase tracking-widest placeholder:text-white/30 shadow-inner"
                placeholder="e.g. Indie Pop, Hip Hop..."
              />
            </div>

            <div className="space-y-2">
              <label className="text-[9px] md:text-[10px] text-white uppercase font-black tracking-widest ml-1 drop-shadow-sm">Main Objective</label>
              <textarea 
                value={artistData.goals}
                onChange={(e) => setArtistData({ ...artistData, goals: e.target.value })}
                className="w-full bg-black/60 border-2 border-white/20 rounded-xl py-3.5 px-5 text-sm text-white focus:outline-none focus:border-accent-500 h-36 md:h-48 transition-all resize-none font-black uppercase tracking-widest placeholder:text-white/30 shadow-inner"
                placeholder="e.g. Build an email list, grow monthly listeners..."
              />
            </div>

            <button 
              onClick={generateStrategy}
              disabled={loading || !artistData.genre}
              className="w-full btn-primary py-4 md:py-6 rounded-xl md:rounded-2xl text-lg md:text-xl disabled:opacity-50 shadow-[0_0_30px_rgb(var(--brand-600)/0.4)] active:scale-95"
            >
              {loading ? <Loader2 className="animate-spin mx-auto" size={24} /> : (
                <div className="flex items-center justify-center gap-2.5">
                  <Sparkles size={20} />
                  <span className="font-varsity tracking-[0.2em] mt-0.5 font-black">GENERATE ROADMAP</span>
                </div>
              )}
            </button>
          </div>

          <div className="glass p-6 rounded-[1.5rem] border-brand-500/40 bg-brand-500/10 shadow-xl">
            <h4 className="text-[10px] font-black text-brand-500 flex items-center gap-2.5 mb-3 uppercase tracking-widest drop-shadow-md">
              <EyeOff size={16} /> NOISE BLOCKER SYSTEM
            </h4>
            <p className="text-[11px] text-white leading-relaxed font-mono uppercase font-black tracking-tight drop-shadow-sm">
              MBLU prioritizes fan ownership over platform-rented audiences. Focus on your database, not vanity metrics.
            </p>
          </div>
        </div>

        <div className="lg:col-span-2">
          {roadmap ? (
            <div className="glass p-8 md:p-12 rounded-[2rem] md:rounded-[2.5rem] min-h-[600px] flex flex-col border-white/20 shadow-[0_0_50px_rgba(0,0,0,0.5)]">
              <div className="flex justify-between items-center mb-8 border-b border-white/10 pb-6">
                <div className="text-[11px] text-accent-500 font-black tracking-[0.4em] uppercase flex items-center gap-2.5 drop-shadow-md">
                   <div className="w-2.5 h-2.5 rounded-full bg-accent-500 animate-pulse shadow-[0_0_10px_rgb(var(--accent-500))]"></div>
                   PLAN SYNTHESIZED
                </div>
                <div className="text-[10px] text-white font-mono uppercase tracking-[0.2em] font-black drop-shadow-sm">OFFICIAL STRATEGY OUTPUT</div>
              </div>
              <div className="whitespace-pre-wrap font-mono text-xs md:text-sm leading-relaxed text-white font-black uppercase tracking-widest drop-shadow-md custom-scrollbar overflow-y-auto">
                {roadmap}
              </div>
            </div>
          ) : (
            <div className="glass h-full rounded-[2.5rem] flex flex-col items-center justify-center text-white/10 p-12 md:p-16 border-dashed border-4 border-white/5 shadow-inner">
              <Sparkles size={80} className="mb-6 opacity-10" />
              <p className="font-varsity text-center tracking-[0.4em] text-base text-white/30 uppercase font-black">SYSTEM READY: WAITING FOR PARAMETERS</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default StrategyLab;
