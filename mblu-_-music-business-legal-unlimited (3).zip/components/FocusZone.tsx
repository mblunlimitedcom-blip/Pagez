
import React, { useState, useEffect, useRef } from 'react';
import { Play, Pause, RotateCcw, Sparkles } from 'lucide-react';

const FocusZone: React.FC = () => {
  const [timeLeft, setTimeLeft] = useState(25 * 60);
  const [isActive, setIsActive] = useState(false);
  const timerRef = useRef<any>(null);

  const toggleTimer = () => setIsActive(!isActive);
  const resetTimer = () => {
    setIsActive(false);
    setTimeLeft(25 * 60);
  };

  useEffect(() => {
    if (isActive && timeLeft > 0) {
      timerRef.current = setInterval(() => {
        setTimeLeft((prev) => prev - 1);
      }, 1000);
    } else if (timeLeft === 0) {
      setIsActive(false);
      if (timerRef.current) clearInterval(timerRef.current);
      alert("VIBE SESSION COMPLETE. RE-UP INITIATED.");
    }

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [isActive, timeLeft]);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <div className="animate-in fade-in slide-in-from-bottom-4 duration-700 h-full flex flex-col items-center justify-center py-10 md:py-20">
      <div className="mb-8 md:mb-12 text-center px-4">
        <h1 className="font-varsity text-2xl md:text-5xl font-black text-slate-900 dark:text-white mb-2 tracking-widest uppercase italic drop-shadow-2xl">VIBE ZONE</h1>
        <p className="text-white dark:text-white text-[9px] md:text-sm font-mono uppercase tracking-[0.3em] font-black drop-shadow-xl italic">25-MINUTE DEEP FLOW PROTOCOL. WRITE, CREATE, OR FIND ZEN.</p>
      </div>

      <div className="relative">
        <div className="absolute inset-0 -m-8 md:-m-20 border-2 border-accent-500/10 rounded-full animate-[spin_60s_linear_infinite]"></div>
        <div className="absolute inset-0 -m-4 md:-m-12 border border-accent-500/20 rounded-full animate-[spin_40s_linear_infinite_reverse]"></div>

        <div className="glass w-64 h-64 xs:w-72 xs:h-72 sm:w-80 sm:h-80 md:w-[28rem] md:h-[28rem] rounded-full flex flex-col items-center justify-center relative z-10 border-2 md:border-4 border-white/20 overflow-hidden shadow-[0_0_100px_rgba(0,0,0,0.8)]">
          <div 
            className="absolute bottom-0 left-0 w-full bg-accent-500/10 transition-all duration-1000"
            style={{ height: `${((25 * 60 - timeLeft) / (25 * 60)) * 100}%` }}
          ></div>

          <Sparkles className={`mb-4 md:mb-6 transition-all duration-700 ${isActive ? 'text-accent-500 animate-pulse scale-110 drop-shadow-[0_0_20px_rgba(245,158,11,0.6)]' : 'text-white/10'}`} size={64} />
          <h2 className="text-[10px] md:text-lg font-varsity text-white/40 tracking-[0.5em] mb-2 md:mb-4 uppercase font-black italic">FLOW_STATE</h2>
          <div className="text-6xl md:text-[9rem] font-varsity font-black text-white tracking-widest drop-shadow-[0_0_30px_rgba(255,255,255,0.3)] italic">
            {formatTime(timeLeft)}
          </div>
          <div className="text-[8px] md:text-sm text-white mt-4 md:mt-8 font-mono uppercase tracking-[0.5em] font-black animate-pulse">
            {isActive ? 'VIBING' : 'STANDBY'}
          </div>
        </div>
      </div>

      <div className="flex gap-6 md:gap-10 mt-12 md:mt-20 relative z-10">
        <button 
          onClick={toggleTimer}
          className={`w-16 h-16 md:w-24 md:h-24 rounded-full flex items-center justify-center transition-all border-2 md:border-4 active:scale-90 shadow-2xl ${
              isActive 
                ? 'bg-zinc-900 text-white border-white/10' 
                : 'bg-accent-600 text-black border-accent-400'
          }`}
        >
          {isActive ? <Pause size={32} /> : <Play size={32} className="ml-1" />}
        </button>
        <button 
          onClick={resetTimer}
          className="w-16 h-16 md:w-24 md:h-24 rounded-full flex items-center justify-center bg-brand-600 text-white border-2 md:border-4 border-brand-400 hover:bg-brand-500 transition-all active:scale-90 shadow-2xl"
        >
          <RotateCcw size={32} />
        </button>
      </div>

      <div className="mt-12 md:mt-24 grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-8 w-full max-w-5xl px-4">
        <TelemetryItem label="Zen" value="Deep" />
        <TelemetryItem label="Sync" value="98%" />
        <TelemetryItem label="Clarity" value="Max" />
        <TelemetryItem label="Filter" value="Active" />
      </div>
    </div>
  );
};

const TelemetryItem: React.FC<{ label: string, value: string }> = ({ label, value }) => (
  <div className="glass p-4 md:p-8 rounded-2xl md:rounded-[2rem] text-center border-white/10 bg-white/5 shadow-xl">
    <div className="text-[8px] md:text-[12px] text-white/40 uppercase tracking-[0.4em] mb-1 md:mb-3 font-black italic">{label}</div>
    <div className="text-sm md:text-xl font-varsity font-black text-accent-500 tracking-[0.2em]">{value}</div>
  </div>
);

export default FocusZone;
