
import React, { useState, useEffect } from 'react';
import { ShieldAlert, Database, Clock, Key, Loader2, UserPlus, Wallet, Hash, Download, Trash2, ShieldX, Cloud, CloudOff, Info, AlertTriangle, CloudUpload, CheckCircle2, ShieldCheck } from 'lucide-react';
import { db, collection, onSnapshot, doc, deleteDoc, isMock, persistenceStatus, uploadToCloud } from '../firebase';

interface RegistryRecord {
  id: string;
  password?: string;
  txid?: string;
  expiry?: number;
  initializedAt?: number;
}

interface Props {
  onRegister: (email: string, pass: string, txid?: string) => Promise<void>;
}

const AdminRegistryView: React.FC<Props> = ({ onRegister }) => {
  const [newEmail, setNewEmail] = useState('');
  const [newPass, setNewPass] = useState('');
  const [newTxid, setNewTxid] = useState('');
  const [artists, setArtists] = useState<RegistryRecord[]>([]);
  const [loading, setLoading] = useState(true);
  const [exporting, setExporting] = useState(false);
  const [lastExportStatus, setLastExportStatus] = useState<string | null>(null);

  useEffect(() => {
    try {
      const unsubscribe = onSnapshot(collection(db, "registry"), (snapshot) => {
        const docs = snapshot.docs.map(doc => ({ 
          id: doc.id, 
          ...doc.data() 
        }));
        setArtists(docs.sort((a: any, b: any) => (b.initializedAt || 0) - (a.initializedAt || 0)) as RegistryRecord[]);
        setLoading(false);
      }, (error) => {
        console.error("Cloud Error:", error);
        setLoading(false);
      });
      return () => unsubscribe();
    } catch (e) {
      console.warn("Member directory sync failed", e);
      setLoading(false);
    }
  }, []);

  const handleRegister = async () => {
    if (!newEmail || !newPass) {
      alert("Email and Password required.");
      return;
    }
    await onRegister(newEmail, newPass, newTxid);
    setNewEmail('');
    setNewPass('');
    setNewTxid('');
  };

  const handleRevoke = async (artistId: string) => {
    if (confirm(`REMOVE ALL ACCESS FOR: ${artistId}?\nThis action is permanent.`)) {
      try {
        await deleteDoc(doc(db, "registry", artistId));
      } catch (e) {
        alert("Action failed.");
      }
    }
  };

  const generateLedgerText = () => {
    const header = `MBLU MEMBER DIRECTORY BACKUP\nGENERATED: ${new Date().toLocaleString()}\nTOTAL ACTIVE MEMBERS: ${artists.length}\n==================================================\n\n`;
    const content = artists.map(a => {
      const initDate = a.initializedAt ? new Date(a.initializedAt).toLocaleString() : 'UNKNOWN';
      const expiryDate = a.expiry ? new Date(a.expiry).toLocaleString() : 'UNKNOWN';
      return `EMAIL:       ${a.id}\nPASSWORD:    ${a.password}\nREF ID:      ${a.txid || 'N/A'}\nJOINED:      ${initDate}\nEXPIRES:     ${expiryDate}\n--------------------------------------------------`;
    }).join('\n');
    return header + content;
  };

  const handleMasterExport = async () => {
    if (artists.length === 0) {
      alert("No data to export.");
      return;
    }

    setExporting(true);
    setLastExportStatus(null);

    const fullText = generateLedgerText();
    const blob = new Blob([fullText], { type: 'text/plain' });

    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `MBLU_DIRECTORY_${new Date().toISOString().split('T')[0]}.txt`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    try {
      const filename = `backups/DIRECTORY_${Date.now()}.txt`;
      await uploadToCloud(filename, blob);
      setLastExportStatus('BACKED UP');
      setTimeout(() => setLastExportStatus(null), 5000);
    } catch (e) {
      setLastExportStatus('SAVED LOCALLY');
      setTimeout(() => setLastExportStatus(null), 5000);
    } finally {
      setExporting(false);
    }
  };

  return (
    <div className="animate-in fade-in slide-in-from-bottom-4 duration-700">
      <div className="flex flex-col md:flex-row md:items-center justify-between mb-8 gap-5">
        <div>
          <div className="flex items-center gap-4">
            <h1 className="font-varsity text-3xl md:text-5xl text-slate-900 dark:text-white tracking-widest flex items-center gap-4 font-black italic drop-shadow-2xl">
              <ShieldAlert className="text-red-600 w-12 h-12 md:w-16 md:h-16 drop-shadow-[0_0_20px_rgba(220,38,38,0.5)]" /> 
              MEMBER <span className="text-zinc-100 dark:text-zinc-100/40">HUB</span>
            </h1>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-10">
        <div className="lg:col-span-5">
          <div className="glass p-8 md:p-10 rounded-[2rem] border-red-500/40 bg-red-500/10 relative overflow-hidden shadow-2xl">
            <div className="absolute top-0 right-0 p-6 text-red-500/5">
              <Wallet size={120} />
            </div>
            <h3 className="font-varsity text-xl md:text-2xl text-white mb-8 tracking-[0.1em] font-black drop-shadow-xl italic">ADD MEMBER</h3>
            <div className="space-y-6 relative z-10">
              <div className="space-y-2">
                <label className="text-[10px] md:text-[11px] font-mono text-white uppercase ml-3 tracking-[0.3em] font-black drop-shadow-md">Official Email</label>
                <input value={newEmail} onChange={e => setNewEmail(e.target.value)} placeholder="artist@mblu" className="w-full bg-black/60 border border-white/20 p-4 rounded-xl text-sm md:text-lg text-white font-mono focus:border-red-500 outline-none transition-all placeholder:text-white/20 font-black uppercase tracking-widest shadow-inner" />
              </div>
              <div className="space-y-2">
                <label className="text-[10px] md:text-[11px] font-mono text-white uppercase ml-3 tracking-[0.3em] font-black drop-shadow-md">Secure Password</label>
                <input value={newPass} onChange={e => setNewPass(e.target.value)} placeholder="••••••••" className="w-full bg-black/60 border border-white/20 p-4 rounded-xl text-sm md:text-lg text-white font-mono focus:border-red-500 outline-none transition-all placeholder:text-white/20 font-black uppercase tracking-widest shadow-inner" />
              </div>
              <div className="space-y-2">
                <label className="text-[10px] md:text-[11px] font-mono text-white uppercase ml-3 tracking-[0.3em] font-black drop-shadow-md">Ref ID</label>
                <input value={newTxid} onChange={e => setNewTxid(e.target.value)} placeholder="REF_CODE" className="w-full bg-black/60 border border-white/20 p-4 rounded-xl text-sm md:text-lg text-white font-mono focus:border-red-500 outline-none transition-all placeholder:text-white/20 font-black uppercase tracking-widest shadow-inner" />
              </div>
              <button onClick={handleRegister} className="w-full bg-red-600 hover:bg-red-500 py-5 md:py-6 rounded-xl md:rounded-2xl font-varsity text-lg md:text-2xl text-white tracking-[0.3em] shadow-xl transition-all active:scale-95 font-black drop-shadow-2xl">
                CREATE ACCOUNT
              </button>
            </div>
          </div>
        </div>

        <div className="lg:col-span-7">
          <div className="glass rounded-[2rem] flex flex-col h-[700px] overflow-hidden border-white/20 shadow-2xl bg-white/5">
            <div className="p-6 md:p-8 border-b border-white/10 bg-black/40 flex flex-col md:flex-row md:items-center justify-between gap-5">
              <div className="flex items-center gap-3">
                <Database className="text-accent-500" size={24} />
                <h3 className="font-varsity text-xl md:text-2xl text-white uppercase tracking-widest mt-0.5 font-black drop-shadow-xl italic">DIRECTORY</h3>
              </div>
              <button 
                onClick={handleMasterExport} 
                disabled={exporting || artists.length === 0}
                className={`flex items-center gap-2.5 px-5 py-2.5 rounded-lg border transition-all font-varsity tracking-[0.2em] font-black shadow-lg ${
                  lastExportStatus === 'BACKED UP' 
                    ? 'bg-emerald-600 text-white border-emerald-400' 
                    : 'bg-indigo-600 hover:bg-indigo-500 text-white border-indigo-400'
                }`}
              >
                 {exporting ? <Loader2 size={16} className="animate-spin" /> : <Download size={16} />}
                 <span className="text-[10px] md:text-xs mt-0.5 uppercase tracking-widest">
                   {exporting ? 'SYNC...' : lastExportStatus ? lastExportStatus : 'EXPORT'}
                 </span>
              </button>
            </div>

            <div className="flex-1 overflow-y-auto p-6 md:p-8 space-y-4 bg-black/40 custom-scrollbar">
              {loading ? (
                <div className="flex flex-col items-center justify-center py-32 gap-6">
                  <Loader2 className="animate-spin text-white w-12 h-12" size={48} />
                  <span className="font-mono text-white text-[10px] tracking-[0.5em] uppercase font-black drop-shadow-2xl animate-pulse">DATABASE_SYNC...</span>
                </div>
              ) : artists.length === 0 ? (
                <div className="text-center py-32">
                  <ShieldAlert size={64} className="mx-auto text-white/10 mb-5" />
                  <p className="text-white font-mono text-xs uppercase tracking-[0.4em] font-black opacity-50 italic">DIRECTORY_EMPTY</p>
                </div>
              ) : (
                artists.map(a => (
                  <div key={a.id} className="group p-6 bg-white/5 border border-white/10 rounded-[1.5rem] md:rounded-[2rem] hover:border-red-500/50 transition-all relative shadow-xl overflow-hidden">
                    <div className="absolute top-0 left-0 w-1.5 h-full bg-white/10 group-hover:bg-red-500 transition-colors"></div>
                    <button 
                      onClick={() => handleRevoke(a.id)}
                      className="absolute top-4 right-4 p-2.5 rounded-lg bg-red-500/10 text-red-500 opacity-0 group-hover:opacity-100 transition-all hover:bg-red-500 hover:text-white border border-red-500/20"
                      title="Remove Member"
                    >
                      <Trash2 size={16} />
                    </button>
                    <div className="flex flex-col md:flex-row justify-between items-start mb-4 gap-3 pr-10 pl-2">
                      <div className="space-y-1">
                        <span className="font-mono text-white text-base md:text-lg block truncate max-w-[200px] md:max-w-[350px] font-black uppercase tracking-widest drop-shadow-lg italic">{a.id}</span>
                        <div className="flex items-center gap-2.5 text-white font-black opacity-60">
                          <Clock size={14} className="text-accent-500" />
                          <span className="text-[9px] font-mono uppercase tracking-[0.2em] drop-shadow-sm">
                            {a.initializedAt ? new Date(a.initializedAt).toLocaleDateString() : 'N/A'}
                          </span>
                        </div>
                      </div>
                      <span className="text-[8px] font-black text-emerald-400 bg-emerald-500/10 border border-emerald-500/30 px-3 py-1 rounded-full tracking-[0.3em] uppercase italic">
                         ACTIVE
                      </span>
                    </div>
                    
                    <div className="pl-2">
                      <div className="flex items-center justify-between gap-3 text-white font-mono text-xs bg-black/60 p-4 rounded-xl border border-white/10 shadow-inner">
                        <div className="flex items-center gap-3">
                          <Key size={14} className="text-accent-500" /> 
                          <span className="tracking-[0.2em] font-black break-all uppercase drop-shadow-md">{a.password}</span>
                        </div>
                        <div className="text-[8px] text-white font-black uppercase tracking-[0.5em] italic opacity-40">KEY</div>
                      </div>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdminRegistryView;
